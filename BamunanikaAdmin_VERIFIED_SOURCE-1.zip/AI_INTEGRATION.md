# Bamunanika Admin V15.2 — AI Assistant integration

## Included in the app

- Admin-only AI Assistant panel, shown after the existing administrator login.
- Text chat and optional browser/WebView speech input and spoken replies where supported.
- Built-in offline help for GPS, case records, backups, receipts and app-update planning.
- Optional HTTPS chat endpoint setting. The app sends only the typed message and fixed app/version/access metadata.
- Advisory-only behavior: the assistant cannot call app functions or apply changes.

## Important: live AI needs a secure backend

The Android app intentionally does **not** contain an AI provider API key. Host a trusted HTTPS backend and configure its `/api/chat` URL in the AI Assistant panel. The backend should authenticate the administrator, validate and limit requests, protect provider credentials in server-side environment variables, apply rate limits, and return JSON such as:

```json
{"reply":"Your answer here"}
```

The client sends a JSON POST with `message`, `app`, and `access` fields. The `access` object explicitly sets `case_records`, `gps`, `photos`, `imei`, `credentials`, and `actions` to false. The app does not include case data or location in this request.

Do not use a public unauthenticated proxy. Restrict CORS to the app's trusted origin where possible. A URL saved in the app is not a secret; never enter an API key into the URL field.

## Build

Open the `BamunanikaAdmin` folder as an Android Gradle project, use JDK 17 and Gradle 8.9 or a compatible Android Studio setup, then run:

```bash
gradle :app:assembleDebug
```

The debug APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- Speech recognition is optional and depends on Android WebView/browser support and microphone permission. Text chat remains available.
- This source package does not include a hosted AI backend or an APK. Live AI remains disconnected until an HTTPS backend is deployed and configured.
- The existing app stores case records locally. This AI panel does not read or transmit them.
