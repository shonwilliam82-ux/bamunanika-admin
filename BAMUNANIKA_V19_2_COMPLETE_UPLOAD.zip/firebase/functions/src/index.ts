import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { getDatabase } from "firebase-admin/database";
import { FieldValue, getFirestore } from "firebase-admin/firestore";

initializeApp();
const db = getDatabase();
const audit = getFirestore();

export const approveDevice = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Administrator approval required.");
  }
  const uid = String(request.data?.uid || "");
  const deviceId = String(request.data?.deviceId || "");
  if (!uid || !deviceId || !/^[A-Za-z0-9_-]{8,80}$/.test(deviceId)) {
    throw new HttpsError("invalid-argument", "Valid uid and deviceId are required.");
  }
  const reqSnap = await db.ref(`deviceRequests/${uid}`).get();
  if (!reqSnap.exists()) throw new HttpsError("not-found", "Device request not found.");
  const req = reqSnap.val();
  const now = Date.now();
  await db.ref().update({
    [`devices/${deviceId}`]: {
      ownerUid: uid, deviceName: String(req.deviceName || "Device").slice(0,80),
      platform: String(req.platform || "unknown").slice(0,30),
      status: "approved", registeredAt: now, approvedBy: request.auth.uid,
      lastSeen: now
    },
    [`deviceRequests/${uid}/status`]: "approved",
    [`deviceRequests/${uid}/reviewedAt`]: now,
    [`deviceRequests/${uid}/reviewedBy`]: request.auth.uid
  });
  await audit.collection("adminAudit").add({
    actorUid: request.auth.uid, action: "device.approved", targetUid: uid,
    deviceId, createdAt: FieldValue.serverTimestamp()
  });
  return { ok: true, deviceId, status: "approved" };
});

export const revokeDevice = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Administrator approval required.");
  }
  const deviceId = String(request.data?.deviceId || "");
  if (!deviceId) throw new HttpsError("invalid-argument", "deviceId required.");
  const ref = db.ref(`devices/${deviceId}`);
  const snap = await ref.get();
  if (!snap.exists()) throw new HttpsError("not-found", "Device not found.");
  await ref.update({ status: "revoked", revokedAt: Date.now(), revokedBy: request.auth.uid });
  await audit.collection("adminAudit").add({
    actorUid: request.auth.uid, action: "device.revoked", deviceId,
    createdAt: FieldValue.serverTimestamp()
  });
  return { ok: true, deviceId, status: "revoked" };
});
