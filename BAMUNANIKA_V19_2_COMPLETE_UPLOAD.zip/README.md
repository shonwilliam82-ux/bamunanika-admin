# BAMUNANIKA V19.2 — Complete Upload Package

This package preserves the existing V19.2 Command Center source and gathers the Firebase security/backend starter, Field App starter, and Android build workflow in one upload.

## What is included
- `command-center/`: original V19.2 HTML, PWA assets, icons, README and original source ZIP, preserved.
- `field-app/`: Field App enrolment/location starter. It requires the Firebase Web App config before it can connect.
- `firebase/`: Realtime Database rules, Firebase project config and callable Cloud Functions for admin device approval/revocation.
- `.github/workflows/`: Android debug APK build workflow for the preserved Command Center source.

## Important implementation status
This is a consolidated source package, **not a verified production deployment**.
- The original Command Center still contains its existing demo/local login and local-storage features. Do not use that login as real authentication or expose the app as a secure production command system.
- The Field App is a starter; Firebase Web App config must be supplied from the existing `Bamunanika-web` app in Firebase Console.
- The Cloud Functions require deployment and admin custom claims set through a trusted Admin SDK process. No service-account key is included.
- The security rules are a starting point and must be tested in Firebase Emulator/Rules Playground against existing data before deployment.
- CCTV support is limited to camera URLs/streams for cameras the operator is authorized to access and that expose a compatible stream. There is no automatic discovery or guaranteed 60 m range.
- 10,000 registered devices is a design target, not a tested capacity claim. Run load tests and configure monitoring, indexes, pagination, backup/restore and rate limits before production.

## Preserve existing Firebase project
Project: `v9-command`
Realtime Database: `https://v9-command-default-rtdb.europe-west1.firebasedatabase.app`
Existing Android app registration: `com.bamunanika.command`
Existing web app: `Bamunanika-web`
Do not delete or replace existing Firebase apps or data. Back up current database rules and data before any deployment.

## One-upload GitHub process
1. Upload `BAMUNANIKA_V19_2_COMPLETE_UPLOAD.zip` to the root of `shonwilliam82-ux/bamunanika-admin`.
2. GitHub does not automatically extract ZIP files in the repository. The workflow expects the ZIP at the repository root and extracts its Command Center files during the build.
3. Ensure the workflow file is placed at `.github/workflows/build-v19-2-android-apk.yml` (it is also included inside this ZIP).
4. Run it from GitHub Actions. Download the APK from the successful run's Artifacts section.

## Firebase setup still required
1. Copy the Firebase Web App configuration for `Bamunanika-web` into `field-app/firebase-config.example.js` and rename it to `firebase-config.js`.
2. Install Firebase CLI and deploy Functions only after reviewing the project and backing up existing data/rules:
   `cd firebase && npm install && npm run build`
   `firebase deploy --only functions,database`
3. Set the admin custom claim using a trusted Admin SDK environment; never grant admin from client-side code.
4. Test pending request, approval, owner-only location write, revocation and admin audit with test accounts before real use.

## Security
Never commit service-account private keys, user passwords, or other server credentials. Location capture in the Field App is user-triggered; no hidden background tracking is implemented.
