// Copy the Firebase Web App configuration from Firebase Console > Project settings > Your apps.
// Use the web app named Bamunanika-web in project v9-command.
// Never place a Firebase service-account JSON or private key in this file.
window.BAMUNANIKA_FIREBASE_CONFIG = {
  apiKey: "REPLACE_WITH_FIREBASE_WEB_API_KEY",
  authDomain: "v9-command.firebaseapp.com",
  databaseURL: "https://v9-command-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "v9-command",
  storageBucket: "v9-command.firebasestorage.app",
  messagingSenderId: "447077998648",
  appId: "REPLACE_WITH_BAMUNANIKA_WEB_APP_ID"
};
