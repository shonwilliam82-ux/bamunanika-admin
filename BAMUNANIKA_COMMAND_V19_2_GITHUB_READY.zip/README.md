# BAMUNANIKA COMMAND V19.2 — GitHub Pages package

## Files
- `index.html` — original V19 dashboard with the PWA installer corrected.
- `manifest.json` — valid web app manifest.
- `sw.js` — same-origin service worker with an offline app shell.
- `icon-192.png`, `icon-512.png` — correctly sized app icons made from the supplied B CMD logo.

## Publish on GitHub Pages
1. Upload all five files to the same folder at the root of the repository.
2. Ensure the main page is named exactly `index.html` (lowercase).
3. In GitHub, open **Settings → Pages** and publish from the `main` branch and `/ (root)` (or the folder where you uploaded all files).
4. Open the published HTTPS site in Chrome on Android.
5. Sign in, then tap **INSTALL APP**. If Chrome does not show the prompt, use Chrome ⋮ → **Install app** / **Add to Home screen**.

## Important limitations
- The dashboard keeps its existing V19 local browser storage. Data is stored on that device/browser; this package does not add cloud sync or multi-user server storage.
- The offline cache includes the app shell and icons. External map tiles, Google Fonts, and other third-party resources still need internet access.
- GPS, camera, and service workers require a secure context (HTTPS on the published site; localhost for development).
- The existing interface contains demo/sample operational values and a local demo login. Do not treat it as a secured production dispatch system until real authentication, server-side storage, access control, and audit integrity are implemented.
