# BAMUNANIKA V9 — Tactical Command Center

Black graphite 3D-style interface with light-blue holographic lighting, silver bevels, raised glass panels, and a local-first operations core. The same responsive Flutter application targets Android and Windows 11. The visual theme is deep black graphite with light-blue holographic accents and silver metallic borders.

## Working features in this source

- First-run consent and local administrator passcode (salted SHA-256 hash in device preferences).
- SQLite database core: relational record index, stable record IDs, atomic collection saves, schema metadata, and one-time migration of existing prototype JSON records. Android uses native SQLite; Windows uses SQLite FFI.
- Guest directory: register, search, edit, delete, and persist records locally.
- Case register: create, search, edit, delete, assign category/priority, and change case status.
- Local device registration and unique installation ID.
- User-triggered GPS location fix and visible foreground location stream, with permission checks and OpenStreetMap view.
- User-triggered Android camera capture and microphone audio recording after runtime permission prompts; Windows uses image-file selection for the media register and microphone recording where supported. Photos are copied into persistent app storage.
- Local media register with photo preview, file sharing, and confirmed deletion.
- JSON backup export containing guest, case, media index, device, and audit records from the SQLite-backed data layer.
- Local audit trail for administrative changes and media actions.
- Responsive navigation and dashboard shortcuts wired to the corresponding forms and pages.

## Features that require additional services or hardware

These are intentionally shown as unavailable/not configured rather than simulated as live capabilities:

- **Cloud sync / multi-user accounts:** requires a Firebase or equivalent backend project, authentication, database rules, and deployment configuration. The included Firebase service is a safe stub and does not sync data.
- **Background or multi-phone GPS tracking:** requires a separately installed companion app on each enrolled device, explicit consent, secure backend, and an Android foreground-service implementation. This project only tracks the device running the app while it is open and the user enables it.
- **AI threat analysis:** requires a selected AI provider, secured server-side credentials, privacy controls, and defined analysis workflows. Current insights are local record counts only.
- **Drone control:** requires a supported drone model, its SDK/API, network pairing, and operator authorization. No drone is controlled by this app.
- **Face recognition:** requires a lawful, consent-based biometric provider and secure processing/storage design. No face identification is performed by this app.
- **Satellite imagery / live feeds:** the map uses OpenStreetMap tiles; the globe and radar are visual dashboard elements, not satellite or radar feeds.

## Verification and acceptance checks

This is a V9-branded Flutter implementation based on the supplied local-first operations source; it is not a pixel-for-pixel port of the original HTML dashboard. The automated Flutter test suite covers salted local passcode storage and verification, local record persistence, stable device registration IDs, and the consent screen's local-only disclosure. CI runs `flutter analyze` and `flutter test` before producing either platform artifact.

A successful CI build proves compilation and automated tests only. It does not prove that device-specific GPS, camera, microphone, Windows packaging, cloud services, or external hardware integrations work on every target device. Those require hands-on installation and acceptance testing.

## Build locally

Install Flutter stable, Android SDK (for APK), and Visual Studio with Desktop development with C++ (for Windows). From this directory:

```bash
flutter pub get
flutter create --platforms=android,windows --org com.bamunanika.admin .
flutter analyze
flutter test
flutter build apk --debug
flutter build windows --release
```

The repository workflow `.github/workflows/build-v9-tactical.yml` creates Android and Windows targets on GitHub Actions and uploads build artifacts. A build is not considered verified until the workflow completes successfully and the artifacts are installed/launched on target devices.

## Android permissions

The Android build needs INTERNET, ACCESS_COARSE_LOCATION, ACCESS_FINE_LOCATION, CAMERA, and RECORD_AUDIO. The app requests location, camera, and microphone access only when the administrator activates the related tool. Location sharing is visible and can be stopped by the device user.

## Security note

The local passcode protects this app's local screen only. It is not a production server identity system. Do not store highly sensitive records on a shared or unmanaged device. Configure secure authentication, encrypted transport, access control, retention, and backup policies before operational deployment.
