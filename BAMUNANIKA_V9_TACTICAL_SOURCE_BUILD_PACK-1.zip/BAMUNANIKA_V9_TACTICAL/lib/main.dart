import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' show FontFeature;
import 'package:crypto/crypto.dart';
import 'package:cross_file/cross_file.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart' as sqflite;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:uuid/uuid.dart';
import 'services/firebase_service.dart';

const bg = Color(0xFF020407);
const panel = Color(0xF009111A);
const panel2 = Color(0xFF080D14);
const accent = Color(0xFF8BD9FF); // light-blue holographic accent
const holoGreen = Color(0xFF00FF9D);
const holoGold = Color(0xFFFFC857);
const muted = Color(0xFF91B7C7);
const line = Color(0x887DBDDF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DB.initialize();
  await FirebaseService.initializeIfConfigured();
  runApp(const BamunanikaApp());
}

class BamunanikaApp extends StatelessWidget {
  const BamunanikaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'BAMUNANIKA V9 HOLOGRAPHIC COMMAND', debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: accent, secondary: holoGreen, surface: panel),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel2,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: line)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: line)),
      ),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
        backgroundColor: accent, foregroundColor: const Color(0xFF001018), elevation: 8,
        shadowColor: accent.withOpacity(.45), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11), side: const BorderSide(color: Color(0xFF8AF7FF))),
        textStyle: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: .6),
      )),
      outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
        foregroundColor: accent, side: const BorderSide(color: line), elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
      )),
    ),
    home: const Gate(),
  );
}

class DB {
  static Future<SharedPreferences> get p => SharedPreferences.getInstance();
  static sqflite.Database? _database;
  static Future<sqflite.Database> get database async {
    if (_database != null) return _database!;
    await initialize();
    return _database!;
  }

  /// SQLite persistence for Android and Windows, with one-time legacy migration.
  static Future<void> initialize({String? databasePath}) async {
    if (_database != null) return;
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      sqfliteFfiInit();
      sqflite.databaseFactory = databaseFactoryFfi;
    }
    final path = databasePath ?? '${await sqflite.getDatabasesPath()}${Platform.pathSeparator}bamunanika_v9.db';
    _database = await sqflite.openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('CREATE TABLE records (collection TEXT NOT NULL, record_id TEXT NOT NULL, position INTEGER NOT NULL, payload TEXT NOT NULL, created_at TEXT, updated_at TEXT, PRIMARY KEY (collection, record_id))');
      await db.execute('CREATE INDEX idx_records_collection_position ON records(collection, position)');
      await db.execute('CREATE TABLE app_meta (meta_key TEXT PRIMARY KEY, meta_value TEXT NOT NULL)');
      await db.insert('app_meta', {'meta_key': 'schema_version', 'meta_value': '1'});
    });
    await _migratePreferences();
  }

  static Future<void> _migratePreferences() async {
    final prefs = await p;
    final db = await _database!;
    final migration = await db.query('app_meta', where: 'meta_key = ?', whereArgs: ['legacy_preferences_migrated'], limit: 1);
    if (migration.isNotEmpty) return;
    const keys = ['guests', 'cases', 'media', 'devices', 'activity'];
    for (final key in keys) {
      final existing = await db.query('records', columns: ['record_id'], where: 'collection = ?', whereArgs: [key], limit: 1);
      if (existing.isNotEmpty) continue;
      final raw = prefs.getString(key);
      if (raw == null) continue;
      try {
        final decoded = jsonDecode(raw);
        if (decoded is! List) continue;
        await db.transaction((txn) async {
          for (var i = 0; i < decoded.length; i++) {
            final item = Map<String, dynamic>.from(decoded[i] as Map);
            final id = (item['id'] ?? const Uuid().v4()).toString();
            item['id'] = id;
            await txn.insert('records', {'collection': key, 'record_id': id, 'position': i, 'payload': jsonEncode(item), 'created_at': item['created']?.toString() ?? item['time']?.toString(), 'updated_at': item['updated']?.toString()}, conflictAlgorithm: sqflite.ConflictAlgorithm.replace);
          }
        });
      } catch (_) {
        // Preserve malformed legacy data for manual recovery; never silently erase it.
      }
    }
    await db.insert('app_meta', {'meta_key': 'legacy_preferences_migrated', 'meta_value': DateTime.now().toIso8601String()}, conflictAlgorithm: sqflite.ConflictAlgorithm.replace);
  }

  static Future<bool> terms() async => (await p).getBool('terms') ?? false;
  static Future<void> accept() async => (await p).setBool('terms', true);
  static Future<String?> pin() async => (await p).getString('admin_pin');
  static Future<void> setPin(String value) async {
    final random = math.Random.secure();
    final salt = List<int>.generate(16, (_) => random.nextInt(256));
    final digest = sha256.convert([...salt, ...utf8.encode(value)]).toString();
    await (await p).setString('admin_pin', 'sha256:${base64Encode(salt)}:$digest');
  }
  static Future<bool> verifyPin(String value) async {
    final stored = await pin();
    if (stored == null) return false;
    if (!stored.startsWith('sha256:')) {
      if (stored != value) return false;
      await setPin(value);
      return true;
    }
    final parts = stored.split(':');
    if (parts.length != 3) return false;
    try {
      final salt = base64Decode(parts[1]);
      return sha256.convert([...salt, ...utf8.encode(value)]).toString() == parts[2];
    } catch (_) { return false; }
  }
  static Future<List<Map<String, dynamic>>> list(String collection) async {
    final db = await database;
    final rows = await db.query('records', where: 'collection = ?', whereArgs: [collection], orderBy: 'position ASC');
    return rows.map((row) => Map<String, dynamic>.from(jsonDecode(row['payload'] as String) as Map)).toList();
  }
  static Future<void> save(String collection, List<Map<String, dynamic>> records) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('records', where: 'collection = ?', whereArgs: [collection]);
      for (var i = 0; i < records.length; i++) {
        final item = Map<String, dynamic>.from(records[i]);
        final id = (item['id'] ?? const Uuid().v4()).toString();
        item['id'] = id;
        await txn.insert('records', {'collection': collection, 'record_id': id, 'position': i, 'payload': jsonEncode(item), 'created_at': item['created']?.toString() ?? item['time']?.toString(), 'updated_at': item['updated']?.toString()}, conflictAlgorithm: sqflite.ConflictAlgorithm.replace);
      }
    });
  }
  static Future<Map<String, int>> counts() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT collection, COUNT(*) AS total FROM records GROUP BY collection');
    return {for (final row in rows) row['collection'] as String: row['total'] as int};
  }
  static Future<String> localDeviceId() async {
    final prefs = await p;
    var id = prefs.getString('local_device_id');
    if (id == null || id.isEmpty) { id = const Uuid().v4(); await prefs.setString('local_device_id', id); }
    return id;
  }
}
class Gate extends StatefulWidget { const Gate({super.key}); @override State<Gate> createState() => _GateState(); }
class _GateState extends State<Gate> {
  bool? accepted;
  @override void initState() { super.initState(); DB.terms().then((v) { if (mounted) setState(() => accepted = v); }); }
  @override Widget build(BuildContext context) {
    if (accepted == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return accepted! ? const Login() : Terms(onYes: () async { await DB.accept(); if (mounted) setState(() => accepted = true); });
  }
}

class Terms extends StatelessWidget {
  final VoidCallback onYes;
  const Terms({super.key, required this.onYes});
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 620), child: Padding(padding: const EdgeInsets.all(22), child: _glass(Column(
      mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Brand(), const SizedBox(height: 24), const Text('TERMS & CONSENT', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12), const Text('• A location fix is requested only when the device owner selects LOCATE NOW.\n• Location is not uploaded or shared with another device in this development build.\n• Camera and microphone are accessed only after the user starts those tools and grants permission.\n• No covert tracking or recording is permitted.\n• Guest, case and media indexes are stored locally; cloud sync is not yet connected.\n• Before any future sharing feature is enabled, the device owner must be informed, actively opt in, see a persistent sharing status, and be able to stop sharing.' , style: TextStyle(color: muted, height: 1.5)),
        const SizedBox(height: 20), SizedBox(width: double.infinity, child: FilledButton(onPressed: onYes, child: const Text('I HAVE READ AND ACCEPT'))),
      ],
    ))),
  )));
}

class Login extends StatefulWidget { const Login({super.key}); @override State<Login> createState() => _LoginState(); }
class _LoginState extends State<Login> {
  final ctrl = TextEditingController(); bool setup = false; bool ready = false; String error = '';
  @override void initState() { super.initState(); DB.pin().then((v) { if (mounted) setState(() { setup = v == null; ready = true; }); }); }
  Future<void> go() async {
    final value = ctrl.text.trim(); if (value.length < 6) { setState(() => error = 'Use at least 6 characters.'); return; }
    if (setup) await DB.setPin(value);
    if (await DB.verifyPin(value)) { if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home())); }
    else { setState(() => error = 'Incorrect passcode.'); }
  }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460), child: Padding(padding: const EdgeInsets.all(22), child: _glass(Column(
    mainAxisSize: MainAxisSize.min, children: [const Brand(), const SizedBox(height: 26), Text(setup ? 'CREATE ADMIN PASSCODE' : 'ADMIN SIGN IN', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.1)), const SizedBox(height: 14),
      TextField(controller: ctrl, obscureText: true, decoration: const InputDecoration(labelText: 'Passcode (minimum 6 characters)')),
      if (error.isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(error, style: const TextStyle(color: Colors.redAccent))),
      const SizedBox(height: 14), SizedBox(width: double.infinity, child: FilledButton(onPressed: ready ? go : null, child: const Text('CONTINUE'))),
      const SizedBox(height: 12), const Text('Local prototype security. A production multi-user admin account requires a configured secure backend.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11)),
    ],
  ))))));
  @override void dispose() { ctrl.dispose(); super.dispose(); }
}

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState() => _HomeState(); }
class _HomeState extends State<Home> {
  int tab = 0;
  List<Map<String, dynamic>> guests = [], cases = [], media = [], devices = [], activity = [];
  String localDeviceId = '';
  bool databaseReady = false;
  Position? position; bool sharing = false, busy = false, recording = false;
  StreamSubscription<Position>? locationSubscription;
  String gpsStatus = 'Waiting for location permission', mediaStatus = 'Camera and microphone are idle';
  String locationPermissionStatus = 'CHECKING', cameraPermissionStatus = 'NOT CHECKED', microphonePermissionStatus = 'NOT CHECKED';
  String guestQuery = '', caseQuery = '';
  String? latestPhoto, latestAudio;
  final picker = ImagePicker(); final recorder = AudioRecorder();
  final mapController = MapController();
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      guests = await DB.list('guests'); cases = await DB.list('cases'); media = await DB.list('media'); devices = await DB.list('devices'); activity = await DB.list('activity');
      localDeviceId = await DB.localDeviceId();
      var migratedMedia = false;
      for (final item in media) { if (item['id'] == null) { item['id'] = const Uuid().v4(); migratedMedia = true; } }
      if (migratedMedia) await DB.save('media', media);
      await DB.counts();
      if (mounted) setState(() => databaseReady = true);
      await refreshPermissionStatuses();
    } catch (e) { if (mounted) { setState(() => databaseReady = false); notify('Database could not be loaded: $e'); } }
  }
  Future<void> refreshPermissionStatuses() async {
    try {
      if (Platform.isWindows) {
        final serviceOn = await Geolocator.isLocationServiceEnabled();
        if (mounted) setState(() {
          locationPermissionStatus = serviceOn ? 'LOCATION SERVICE AVAILABLE' : 'LOCATION SERVICE OFF';
          cameraPermissionStatus = 'IMAGE FILE PICKER';
          microphonePermissionStatus = 'RECORDER CHECKS ACCESS';
        });
        return;
      }
      final serviceOn = await Geolocator.isLocationServiceEnabled();
      final location = await Geolocator.checkPermission();
      final camera = await Permission.camera.status;
      final microphone = await Permission.microphone.status;
      if (!mounted) return;
      setState(() {
        locationPermissionStatus = !serviceOn ? 'GPS SERVICE OFF' : (location == LocationPermission.deniedForever ? 'PERMANENTLY DENIED' : (location == LocationPermission.denied ? 'NOT GRANTED' : 'GRANTED'));
        cameraPermissionStatus = camera.isGranted ? 'GRANTED' : camera.isPermanentlyDenied ? 'PERMANENTLY DENIED' : 'NOT GRANTED';
        microphonePermissionStatus = microphone.isGranted ? 'GRANTED' : microphone.isPermanentlyDenied ? 'PERMANENTLY DENIED' : 'NOT GRANTED';
      });
    } catch (e) { if (mounted) setState(() => locationPermissionStatus = 'STATUS UNAVAILABLE'); }
  }
  Future<void> logActivity(String action, String detail) async {
    activity.insert(0, {'id': const Uuid().v4(), 'action': action, 'detail': detail, 'time': DateTime.now().toIso8601String(), 'deviceId': localDeviceId});
    if (activity.length > 500) activity = activity.take(500).toList();
    await DB.save('activity', activity);
    if (mounted) setState(() {});
  }
  Future<void> exportBackup() async {
    try {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/bamunanika_v9_backup_${DateTime.now().millisecondsSinceEpoch}.json');
      final payload = <String, dynamic>{
        'app': 'BAMUNANIKA ADMIN V9',
        'exportedAt': DateTime.now().toIso8601String(),
        'deviceId': localDeviceId,
        'guests': guests,
        'cases': cases,
        'media': media,
        'devices': devices,
        'activity': activity,
      };
      await file.writeAsString(const JsonEncoder.withIndent('  ').convert(payload));
      await Share.shareXFiles([XFile(file.path)], text: 'BAMUNANIKA ADMIN V9 local data backup');
    } catch (e) { notify('Backup export failed: $e'); }
  }
  void notify(String s) { if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s))); }
  Future<bool> locationPermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) { notify(Platform.isWindows ? 'Windows location services are switched off.' : 'GPS is switched off. Turn on Location in Android settings.'); return false; }
    if (Platform.isWindows) return true;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.deniedForever || p == LocationPermission.denied) { await refreshPermissionStatuses(); notify('Location permission denied. Allow it in App info > Permissions.'); return false; }
    await refreshPermissionStatuses();
    return true;
  }
  Future<void> locate() async {
    if (busy) return; setState(() { busy = true; gpsStatus = 'Requesting GPS fix…'; });
    try {
      if (!await locationPermission()) return;
      final service = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 25)));
      if (!mounted) return; setState(() { position = service; gpsStatus = 'GPS FIX ACQUIRED • ${service.latitude.toStringAsFixed(6)}, ${service.longitude.toStringAsFixed(6)}'; }); if (tab == 3) { mapController.move(LatLng(service.latitude, service.longitude), 16); }
    } catch (e) { notify('Could not get GPS fix: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> toggleSharing(bool value) async {
    if (!value) {
      await locationSubscription?.cancel();
      locationSubscription = null;
      if (mounted) setState(() => sharing = false);
      await logActivity('GPS SHARING STOPPED', 'Foreground location stream stopped by administrator');
      notify('Live GPS updates stopped.');
      return;
    }
    if (sharing || busy || !await locationPermission()) return;
    await locate();
    if (!mounted || position == null || !gpsStatus.startsWith('GPS FIX ACQUIRED')) return;
    await locationSubscription?.cancel();
    locationSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10,
      ),
    ).listen(
      (nextPosition) {
        if (!mounted) return;
        setState(() {
          position = nextPosition;
          gpsStatus = 'LIVE GPS • ${nextPosition.latitude.toStringAsFixed(6)}, ${nextPosition.longitude.toStringAsFixed(6)}';
        });
      },
      onError: (Object error) {
        locationSubscription?.cancel();
        locationSubscription = null;
        if (mounted) { setState(() => sharing = false); notify('Live GPS stream stopped after an error: $error'); }
      },
      onDone: () { if (mounted) setState(() => sharing = false); },
    );
    if (mounted) {
      setState(() => sharing = true);
      await logActivity('GPS SHARING STARTED', 'Visible foreground-only location updates enabled');
      notify('Live GPS updates are ON while this app remains open. Location is not sent to another device.');
    }
  }
  Future<void> addGuest(Map<String, String> fields) async {
    final id = const Uuid().v4(); final code = 'BAM-${const Uuid().v4().substring(0, 8).toUpperCase()}';
    guests.insert(0, {'id': id, ...fields, 'code': code, 'created': DateTime.now().toIso8601String()});
    await DB.save('guests', guests); await logActivity('GUEST CREATED', '${fields['name'] ?? 'Guest'} • $code'); if (mounted) setState(() {}); notify('Guest saved on this device. Code: $code');
  }
  Future<void> addCase(Map<String, String> fields) async {
    cases.insert(0, {'id': const Uuid().v4(), ...fields, 'status': 'OPEN', 'created': DateTime.now().toIso8601String()});
    await DB.save('cases', cases); await logActivity('CASE CREATED', '${fields['title'] ?? 'Case'}'); if (mounted) setState(() {}); notify('Case saved locally.');
  }
  Future<void> capturePhoto() async {
    try {
      if (!Platform.isWindows) {
        final permission = await Permission.camera.request();
        await refreshPermissionStatuses();
        if (!permission.isGranted) { if (mounted) setState(() => mediaStatus = 'Camera permission denied. Enable Camera in Android App permissions.'); return; }
      }
      final file = await picker.pickImage(source: Platform.isWindows ? ImageSource.gallery : ImageSource.camera, imageQuality: 88);
      if (file == null) { if (mounted) setState(() => mediaStatus = 'Camera or image selection was cancelled.'); return; }
      final docs = await getApplicationDocumentsDirectory();
      final mediaFolder = Directory('${docs.path}${Platform.pathSeparator}bamunanika_media');
      await mediaFolder.create(recursive: true);
      final extension = file.path.contains('.') ? file.path.substring(file.path.lastIndexOf('.')) : '.jpg';
      final savedPath = '${mediaFolder.path}${Platform.pathSeparator}photo_${DateTime.now().millisecondsSinceEpoch}$extension';
      final savedFile = await File(file.path).copy(savedPath);
      final savedName = savedPath.split(Platform.pathSeparator).last;
      latestPhoto = savedFile.path;
      media.insert(0, {'id': const Uuid().v4(), 'type': 'PHOTO', 'path': savedFile.path, 'name': savedName, 'time': DateTime.now().toIso8601String()});
      await DB.save('media', media);
      await logActivity('PHOTO CAPTURED', savedName);
      if (mounted) setState(() => mediaStatus = 'Photo saved in app storage: $savedName');
    } catch (e) { if (mounted) setState(() => mediaStatus = 'Camera failed: $e'); }
  }
  Future<void> startRecording() async {
    try {
      if (!Platform.isWindows) {
        final permission = await Permission.microphone.request();
        await refreshPermissionStatuses();
        if (!permission.isGranted) { if (mounted) setState(() => mediaStatus = 'Microphone permission denied. Enable Microphone in Android App permissions.'); return; }
      }
      if (!await recorder.hasPermission()) { setState(() => mediaStatus = 'Recorder cannot access microphone. Check Android permission.'); return; }
      final dir = await getApplicationDocumentsDirectory(); final path = '${dir.path}/bamunanika_audio_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
      if (mounted) setState(() { recording = true; mediaStatus = 'RECORDING • Tap STOP to save the audio file.'; });
    } catch (e) { if (mounted) setState(() => mediaStatus = 'Microphone failed: $e'); }
  }
  Future<void> stopRecording() async {
    try {
      final path = await recorder.stop(); if (path != null) { latestAudio = path; media.insert(0, {'id': const Uuid().v4(), 'type': 'AUDIO', 'path': path, 'name': path.split(Platform.pathSeparator).last, 'time': DateTime.now().toIso8601String()}); await DB.save('media', media); await logActivity('AUDIO RECORDED', path.split(Platform.pathSeparator).last); }
      if (mounted) setState(() { recording = false; mediaStatus = path == null ? 'Recording stopped.' : 'Audio saved on this device: $path'; });
    } catch (e) { if (mounted) setState(() { recording = false; mediaStatus = 'Could not stop recording: $e'; }); }
  }
  @override Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 900;
    final pages = [overview(), guestsPage(), casesPage(), mapPage(), devicePage(), recordsPage(), activityPage()];
    const labels = ['Dashboard', 'Guests', 'Cases', 'Live Map', 'Device Tools', 'Records', 'Activity'];
    const icons = [Icons.dashboard_rounded, Icons.people_alt_rounded, Icons.folder_copy_rounded, Icons.map_rounded, Icons.devices_rounded, Icons.perm_media_rounded, Icons.receipt_long_rounded];
    return Scaffold(
      appBar: AppBar(title: const Brand(), actions: [IconButton(tooltip: 'Export local backup', onPressed: exportBackup, icon: const Icon(Icons.ios_share)), IconButton(tooltip: 'Refresh records', onPressed: load, icon: const Icon(Icons.refresh)), const SizedBox(width: 8)]),
      body: Row(children: [
        if (wide) Container(width: 224, decoration: const BoxDecoration(color: Color(0xFF0B121A), border: Border(right: BorderSide(color: line))), child: Column(children: [const SizedBox(height: 12), for (var i = 0; i < labels.length; i++) _navItem(i, labels[i], icons[i]), const Spacer(), Padding(padding: const EdgeInsets.all(14), child: _statusChip('LOCAL DEVICE MODE', Icons.shield_outlined)), const SizedBox(height: 10)])),
        Expanded(child: pages[tab]),
      ]),
      bottomNavigationBar: wide ? null : NavigationBar(backgroundColor: panel2, selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: List.generate(labels.length, (i) => NavigationDestination(icon: Icon(icons[i]), label: labels[i]))),
    );
  }
  Widget _navItem(int index, String label, IconData icon) => Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), child: ListTile(selected: tab == index, selectedTileColor: const Color(0xFF142331), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), leading: Icon(icon, color: tab == index ? accent : muted), title: Text(label, style: TextStyle(color: tab == index ? Colors.white : muted, fontWeight: tab == index ? FontWeight.bold : FontWeight.normal)), onTap: () => setState(() => tab = index)));
  Widget _statusChip(String label, IconData icon) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(color: const Color(0xFF111C27), borderRadius: BorderRadius.circular(30), border: Border.all(color: line)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 15, color: accent), const SizedBox(width: 7), Text(label, style: const TextStyle(fontSize: 10, letterSpacing: 1, color: accent, fontWeight: FontWeight.bold))]));
  Widget _page(List<Widget> children) => LayoutBuilder(builder: (context, c) => ListView(padding: EdgeInsets.all(c.maxWidth > 1000 ? 28 : 16), children: [ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1500), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children))]));
  Widget _heading(String title, String subtitle) => Padding(padding: const EdgeInsets.only(bottom: 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title.toUpperCase(), style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.1)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(color: muted))]));
  Widget _stat(String title, String value, IconData icon, String foot) => _glass(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: accent), const Spacer(), const Icon(Icons.more_horiz, color: muted)]), const SizedBox(height: 13), Text(value, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)), Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(foot, style: const TextStyle(color: muted, fontSize: 11))]));
  Widget _section(String title, Widget child) => _glass(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1, fontSize: 12, color: accent)), const SizedBox(height: 13), child]));
  Widget overview() => _page([
    _glass(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF101820), borderRadius: BorderRadius.circular(13), border: Border.all(color: line)), child: const Icon(Icons.hub_rounded, color: accent, size: 23)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('V9 TACTICAL COMMAND', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1.3, color: accent, shadows: [Shadow(color: accent, blurRadius: 16)])),
          SizedBox(height: 4), Text('TACTICAL HOLOGRAPHIC COMMAND CENTER', style: TextStyle(color: muted, fontSize: 10, letterSpacing: 1.0)),
        ])),
        _statusChip(sharing ? 'GPS STREAM ON' : 'LOCAL CONTROL', sharing ? Icons.gps_fixed : Icons.shield_outlined),
      ]),
      const SizedBox(height: 17),
      Container(height: 1, color: line),
      const SizedBox(height: 14),
      Row(children: [
        const Icon(Icons.verified_user_outlined, color: accent, size: 16),
        const SizedBox(width: 8),
        Expanded(child: Text(sharing ? 'Location updates are active on this device while the app remains open.' : 'System standing by. Location sharing is off until an administrator enables it.', style: const TextStyle(color: muted, fontSize: 11))),
        Text(Platform.operatingSystem.toUpperCase(), style: const TextStyle(color: accent, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
      ]),
    ])),
    const SizedBox(height: 14),
    LayoutBuilder(builder: (context, c) {
      final width = c.maxWidth < 520 ? (c.maxWidth - 10) / 2 : 190.0;
      return Wrap(spacing: 10, runSpacing: 10, children: [
        SizedBox(width: width, child: _commandMetric('GUEST PROFILES', '${guests.length}', Icons.people_alt_rounded, 'Open guest directory', accent, () => setState(() => tab = 1))),
        SizedBox(width: width, child: _commandMetric('ALL CASES', '${cases.length}', Icons.folder_copy_rounded, 'Open case register', const Color(0xFF76B7FF), () => setState(() => tab = 2))),
        SizedBox(width: width, child: _commandMetric('OPEN CASES', '${cases.where((e) => e['status'] != 'CLOSED').length}', Icons.pending_actions_rounded, 'Review case register', const Color(0xFFFFC66D), () => setState(() => tab = 2))),
        SizedBox(width: width, child: _commandMetric('MEDIA FILES', '${media.length}', Icons.perm_media_rounded, 'Open media records', const Color(0xFFB69CFF), () => setState(() => tab = 5))),
        SizedBox(width: width, child: _commandMetric('REGISTERED DEVICES', '${devices.length}', Icons.devices_rounded, 'Open device tools', accent, () => setState(() => tab = 4))),
      ]);
    }),
    const SizedBox(height: 14),
    LayoutBuilder(builder: (context, c) {
      final three = c.maxWidth >= 1120;
      final two = c.maxWidth >= 680;
      final core = _section('SYSTEM CORE  /  SQLITE DATABASE STATUS', Column(children: [
        const SizedBox(height: 4), const HolographicCore(size: 148),
        const SizedBox(height: 8), const Text('LOCAL SQLITE COMMAND CORE', style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        const SizedBox(height: 5), Text('GUESTS ${guests.length}  •  CASES ${cases.length}', style: const TextStyle(color: muted, fontSize: 10)),
        const SizedBox(height: 10), _statusRow('SQLite database', databaseReady ? 'ONLINE • TRANSACTIONAL' : 'INITIALIZING / ERROR', databaseReady ? holoGreen : Colors.orangeAccent),
        _statusRow('Cloud connection', FirebaseService.isReady ? 'INITIALIZED' : 'NOT CONFIGURED', holoGold),
      ]));
      final geo = _section('BAMUNANIKA  /  GEOSPATIAL VIEW', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(height: 218, child: ClipRRect(borderRadius: BorderRadius.circular(12), child: FlutterMap(
          options: const MapOptions(initialCenter: LatLng(0.8409, 32.4966), initialZoom: 12.5),
          children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.bamunanika.admin'),
            MarkerLayer(markers: [Marker(point: position == null ? const LatLng(0.8409, 32.4966) : LatLng(position!.latitude, position!.longitude), width: 42, height: 42, child: const Icon(Icons.location_on, color: accent, size: 38))]),
          ],
        ))),
        const SizedBox(height: 9), Text(position == null ? 'HQ REFERENCE • 0.8409, 32.4966' : 'DEVICE GPS • ${position!.latitude.toStringAsFixed(5)}, ${position!.longitude.toStringAsFixed(5)}', style: const TextStyle(color: muted, fontSize: 10)),
        Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () => setState(() => tab = 3), icon: const Icon(Icons.open_in_full, size: 15), label: const Text('OPEN LIVE MAP'))),
      ]));
      final insights = _section('COMMAND INTELLIGENCE', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.auto_awesome, color: holoGold), SizedBox(width: 8), Text('LOCAL DATA SNAPSHOT', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11, color: holoGold))]),
        const SizedBox(height: 12), _statusRow('Guest profiles', '${guests.length}', accent),
        _statusRow('Open cases', '${cases.where((e) => e['status'] != 'CLOSED').length}', holoGold),
        _statusRow('Media records', '${media.length}', accent),
        _statusRow('Registered devices', '${devices.length}', accent),
        const SizedBox(height: 8), const Text('Insights are calculated from records stored on this device. No remote AI analysis or drone network is connected.', style: TextStyle(color: muted, fontSize: 10, height: 1.45)),
      ]));
      if (three) return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 4, child: core), const SizedBox(width: 12), Expanded(flex: 6, child: geo), const SizedBox(width: 12), Expanded(flex: 4, child: insights)]);
      if (two) return Column(children: [Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: core), const SizedBox(width: 12), Expanded(flex: 2, child: geo)]), const SizedBox(height: 12), insights]);
      return Column(children: [core, const SizedBox(height: 12), geo, const SizedBox(height: 12), insights]);
    }),
    const SizedBox(height: 14),
    LayoutBuilder(builder: (context, c) {
      final split = c.maxWidth >= 760;
      final gpsPanel = _section('LIVE OPERATIONS  /  GPS CONTROL', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: const Color(0xFF101820), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.my_location_rounded, color: accent)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(position == null ? 'LOCATION NOT ACQUIRED' : 'GPS FIX  •  ${position!.accuracy.toStringAsFixed(0)} M ACCURACY', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
            const SizedBox(height: 3), Text(sharing ? 'Continuous foreground updates active' : 'Waiting for an authorised location request', style: const TextStyle(color: muted, fontSize: 10)),
          ])),
          Icon(sharing ? Icons.wifi_tethering : Icons.gps_not_fixed, color: sharing ? accent : muted),
        ]),
        const SizedBox(height: 13),
        Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF070C12), borderRadius: BorderRadius.circular(12), border: Border.all(color: line)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(gpsStatus, style: const TextStyle(color: muted, fontSize: 11)),
          if (position != null) ...[
            const SizedBox(height: 8),
            Text('${position!.latitude.toStringAsFixed(6)}  /  ${position!.longitude.toStringAsFixed(6)}', style: const TextStyle(color: accent, fontSize: 15, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()])),
            Text('Accuracy ${position!.accuracy.toStringAsFixed(1)} m  •  ${position!.timestamp.toLocal()}', style: const TextStyle(color: muted, fontSize: 10)),
          ],
        ])),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: sharing, onChanged: toggleSharing, activeColor: accent, title: const Text('Enable live location updates', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)), subtitle: const Text('Foreground only • visible • stops when disabled or app closes', style: TextStyle(color: muted, fontSize: 10))),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton.icon(onPressed: busy ? null : locate, icon: const Icon(Icons.radar_rounded), label: Text(busy ? 'ACQUIRING…' : 'LOCATE NOW')),
          OutlinedButton.icon(onPressed: () => setState(() => tab = 3), icon: const Icon(Icons.map_outlined), label: const Text('OPEN LIVE MAP')),
        ]),
      ]));
      final quickPanel = _section('COMMAND SHORTCUTS', Column(children: [
        _commandAction('Register a guest', 'Open the new guest form', Icons.person_add_alt_1_rounded, guestDialog),
        _commandAction('Open a case', 'Open the new case form', Icons.add_box_rounded, caseDialog),
        _commandAction('Device tools', 'Local device and permission tools', Icons.phonelink_setup_rounded, () => setState(() => tab = 4)),
        _commandAction('Capture photo', 'Open camera with permission', Icons.camera_alt_rounded, capturePhoto),
        _commandAction(recording ? 'Stop audio recording' : 'Start audio recording', 'Microphone permission required', recording ? Icons.stop_circle_rounded : Icons.mic_rounded, () => recording ? stopRecording() : startRecording()),
        _commandAction('Media & activity records', 'Review captured files and history', Icons.history_rounded, () => setState(() => tab = 5)),
        _commandAction('Audit activity', 'Review changes made in this installation', Icons.receipt_long_rounded, () => setState(() => tab = 6)),
      ]));
      return split ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 6, child: gpsPanel), const SizedBox(width: 14), Expanded(flex: 5, child: quickPanel)]) : Column(children: [gpsPanel, const SizedBox(height: 12), quickPanel]);
    }),
    const SizedBox(height: 14),
    _section('SYSTEM HEALTH  /  INTEGRATION STATUS', Column(children: [
      _statusRow('Location permission / service', locationPermissionStatus, locationPermissionStatus == 'GRANTED' ? accent : Colors.orangeAccent),
      _statusRow('Latest GPS fix', position == null ? 'NO FIX ACQUIRED' : 'AVAILABLE • ${position!.accuracy.toStringAsFixed(0)} M', position == null ? Colors.orangeAccent : accent),
      _statusRow('Live GPS stream', sharing ? 'RUNNING IN FOREGROUND' : 'STOPPED', sharing ? accent : muted),
      _statusRow('Camera permission', cameraPermissionStatus, cameraPermissionStatus == 'GRANTED' ? accent : Colors.orangeAccent),
      _statusRow('Microphone permission', microphonePermissionStatus, microphonePermissionStatus == 'GRANTED' ? accent : Colors.orangeAccent),
      _statusRow('Cloud database', FirebaseService.isReady ? 'INITIALIZED — SYNC NOT VERIFIED' : 'NOT CONFIGURED', Colors.orangeAccent),
      _statusRow('Device registry', devices.any((d) => d['id'] == localDeviceId) ? 'THIS DEVICE REGISTERED' : 'NOT REGISTERED', devices.any((d) => d['id'] == localDeviceId) ? accent : Colors.orangeAccent),
      _statusRow('Data persistence', 'SQLITE • LOCAL DEVICE DATABASE', muted),
      const SizedBox(height: 8),
      Container(width: double.infinity, padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: const Color(0xFF171B1E), borderRadius: BorderRadius.circular(11)), child: const Text('IMPORTANT: Multi-phone tracking and cloud synchronisation are not active. They require a configured backend, authenticated device enrolment, a companion app and explicit consent from each device owner. GPS updates in this build remain on this device and stop when the app closes.', style: TextStyle(color: muted, fontSize: 10, height: 1.45))),
    ])),
  ]);
  Widget _commandMetric(String label, String value, IconData icon, String note, Color tint, VoidCallback onTap) => Material(
    color: Colors.transparent,
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: _glass(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(icon, color: tint, size: 19), const Spacer(), const Icon(Icons.arrow_outward_rounded, color: muted, size: 15)]),
        const SizedBox(height: 14),
        Text(value, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900, height: 1.0, fontFeatures: [FontFeature.tabularFigures()])),
        const SizedBox(height: 7),
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .65)),
        const SizedBox(height: 4),
        Text(note, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 9)),
      ])),
    ),
  );
  Widget _commandAction(String title, String subtitle, IconData icon, VoidCallback action) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Material(color: const Color(0xFF090F16), borderRadius: BorderRadius.circular(12), child: InkWell(borderRadius: BorderRadius.circular(12), onTap: action, child: Padding(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10), child: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: const Color(0xFF101820), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: accent, size: 18)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: muted, fontSize: 9))])), const Icon(Icons.chevron_right_rounded, color: muted, size: 18)])))));
  Widget _action(String label, IconData icon, VoidCallback fn) => OutlinedButton.icon(onPressed: fn, icon: Icon(icon, size: 18), label: Text(label));
  Widget _statusRow(String label, String value, Color color) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: muted))), Text(value, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: .5))]));
  Widget guestsPage() {
    final q = guestQuery.trim().toLowerCase();
    final filtered = guests.where((g) => [g['name'], g['phone'], g['email'], g['address'], g['code']].any((v) => (v ?? '').toString().toLowerCase().contains(q))).toList();
    return _page([_heading('Guest registration', 'Register, search, edit and manage guest profiles.'), Align(alignment: Alignment.centerLeft, child: FilledButton.icon(onPressed: guestDialog, icon: const Icon(Icons.person_add), label: const Text('REGISTER NEW GUEST'))), const SizedBox(height: 12), TextField(onChanged: (v) => setState(() => guestQuery = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search name, phone, email or guest code')), const SizedBox(height: 14), if (filtered.isEmpty) _section('Guest directory', Text(guests.isEmpty ? 'No guest profiles registered yet.' : 'No guests match this search.', style: const TextStyle(color: muted))) else ...filtered.map((g) => _section('${g['name'] ?? 'Guest'}  •  ${g['code'] ?? ''}', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Phone: ${g['phone'] ?? '—'}'), Text('Email: ${g['email'] ?? '—'}'), Text('Address: ${g['address'] ?? '—'}'), Text('Notes: ${g['notes'] ?? '—'}'), Text('Registered: ${g['created'] ?? '—'}', style: const TextStyle(color: muted, fontSize: 11)), const SizedBox(height: 8), Wrap(spacing: 8, children: [OutlinedButton.icon(onPressed: () => editGuest(g), icon: const Icon(Icons.edit, size: 16), label: const Text('EDIT')), TextButton.icon(onPressed: () => deleteGuest(g), icon: const Icon(Icons.delete_outline, size: 16), label: const Text('DELETE', style: TextStyle(color: Colors.redAccent)))])])))]);
  }
  Widget casesPage() {
    final q = caseQuery.trim().toLowerCase();
    final filtered = cases.where((x) => [x['title'], x['id'], x['guestCode'], x['category'], x['priority'], x['assigned'], x['status'], x['details']].any((v) => (v ?? '').toString().toLowerCase().contains(q))).toList();
    return _page([_heading('Case management', 'Create, search, edit and track case records linked to guest reference codes.'), Align(alignment: Alignment.centerLeft, child: FilledButton.icon(onPressed: caseDialog, icon: const Icon(Icons.add), label: const Text('CREATE NEW CASE'))), const SizedBox(height: 12), TextField(onChanged: (v) => setState(() => caseQuery = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search title, reference, guest, status or assignee')), const SizedBox(height: 14), if (filtered.isEmpty) _section('Case register', Text(cases.isEmpty ? 'No cases have been created.' : 'No cases match this search.', style: const TextStyle(color: muted))) else ...filtered.map((x) => _section('${x['title'] ?? 'Case'}  •  ${x['status'] ?? 'OPEN'}', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Reference: ${x['id'] ?? '—'}', style: const TextStyle(color: muted, fontSize: 11)), Text('Guest code: ${x['guestCode'] ?? '—'}'), Text('Category: ${x['category'] ?? 'General'}  •  Priority: ${x['priority'] ?? 'Normal'}'), Text('${x['details'] ?? ''}'), Text('Assigned to: ${x['assigned'] ?? 'Unassigned'}'), Text('Created: ${x['created'] ?? ''}', style: const TextStyle(color: muted, fontSize: 11)), Wrap(spacing: 8, children: [if (x['status'] != 'IN PROGRESS' && x['status'] != 'CLOSED') TextButton(onPressed: () => updateCaseStatus(x, 'IN PROGRESS'), child: const Text('IN PROGRESS')), if (x['status'] != 'CLOSED') TextButton(onPressed: () => updateCaseStatus(x, 'CLOSED'), child: const Text('CLOSE CASE')) else TextButton(onPressed: () => updateCaseStatus(x, 'OPEN'), child: const Text('REOPEN CASE')), TextButton.icon(onPressed: () => editCase(x), icon: const Icon(Icons.edit, size: 16), label: const Text('EDIT')), TextButton.icon(onPressed: () => deleteCase(x), icon: const Icon(Icons.delete_outline, size: 16), label: const Text('DELETE', style: TextStyle(color: Colors.redAccent)))])])))]);
  }
  Future<void> updateCaseStatus(Map<String, dynamic> item, String status) async { final old = item['status'] ?? 'OPEN'; item['status'] = status; item['updated'] = DateTime.now().toIso8601String(); await DB.save('cases', cases); await logActivity('CASE STATUS CHANGED', '${item['title'] ?? item['id']}: $old → $status'); if (mounted) setState(() {}); }

  Future<bool> confirmDelete(String label) async => await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Confirm deletion'), content: Text('Delete $label? This action cannot be undone.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(ctx, true), style: FilledButton.styleFrom(backgroundColor: Colors.redAccent), child: const Text('DELETE'))])) ?? false;
  Future<void> deleteGuest(Map<String, dynamic> item) async { if (!await confirmDelete('this guest profile')) return; guests.removeWhere((g) => g['id'] == item['id']); await DB.save('guests', guests); await logActivity('GUEST DELETED', '${item['name'] ?? item['id']}'); if (mounted) setState(() {}); }
  Future<void> deleteCase(Map<String, dynamic> item) async { if (!await confirmDelete('this case record')) return; cases.removeWhere((x) => x['id'] == item['id']); await DB.save('cases', cases); await logActivity('CASE DELETED', '${item['title'] ?? item['id']}'); if (mounted) setState(() {}); }
  Future<void> editGuest(Map<String, dynamic> item) async {
    final name = TextEditingController(text: '${item['name'] ?? ''}'), phone = TextEditingController(text: '${item['phone'] ?? ''}'), email = TextEditingController(text: '${item['email'] ?? ''}'), address = TextEditingController(text: '${item['address'] ?? ''}'), notes = TextEditingController(text: '${item['notes'] ?? ''}');
    final saved = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Edit guest'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Full name *')), TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone number *')), TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')), TextField(controller: address, decoration: const InputDecoration(labelText: 'Address / area')), TextField(controller: notes, maxLines: 2, decoration: const InputDecoration(labelText: 'Notes'))])), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(ctx, name.text.trim().isNotEmpty && phone.text.trim().isNotEmpty), child: const Text('SAVE CHANGES'))]));
    if (saved == true) { item.addAll({'name': name.text.trim(), 'phone': phone.text.trim(), 'email': email.text.trim(), 'address': address.text.trim(), 'notes': notes.text.trim(), 'updated': DateTime.now().toIso8601String()}); await DB.save('guests', guests); await logActivity('GUEST UPDATED', '${item['name'] ?? item['id']}'); if (mounted) setState(() {}); }
    name.dispose(); phone.dispose(); email.dispose(); address.dispose(); notes.dispose();
  }
  Future<void> editCase(Map<String, dynamic> item) async {
    final title = TextEditingController(text: '${item['title'] ?? ''}'), code = TextEditingController(text: '${item['guestCode'] ?? ''}'), assigned = TextEditingController(text: '${item['assigned'] ?? ''}'), details = TextEditingController(text: '${item['details'] ?? ''}');
    String category = '${item['category'] ?? 'General'}', priority = '${item['priority'] ?? 'Normal'}';
    final saved = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, refresh) => AlertDialog(title: const Text('Edit case'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'Case title *')), TextField(controller: code, decoration: const InputDecoration(labelText: 'Guest registration code')), DropdownButtonFormField<String>(value: ['General','Safety','Incident','Support','Other'].contains(category) ? category : 'General', decoration: const InputDecoration(labelText: 'Category'), items: ['General','Safety','Incident','Support','Other'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => refresh(() => category = v ?? 'General')), DropdownButtonFormField<String>(value: ['Low','Normal','High','Urgent'].contains(priority) ? priority : 'Normal', decoration: const InputDecoration(labelText: 'Priority'), items: ['Low','Normal','High','Urgent'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => refresh(() => priority = v ?? 'Normal')), TextField(controller: assigned, decoration: const InputDecoration(labelText: 'Assigned to')), TextField(controller: details, maxLines: 3, decoration: const InputDecoration(labelText: 'Details / action notes'))])), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(ctx, title.text.trim().isNotEmpty), child: const Text('SAVE CHANGES'))])));
    if (saved == true) { item.addAll({'title': title.text.trim(), 'guestCode': code.text.trim(), 'category': category, 'priority': priority, 'assigned': assigned.text.trim(), 'details': details.text.trim(), 'updated': DateTime.now().toIso8601String()}); await DB.save('cases', cases); await logActivity('CASE UPDATED', '${item['title'] ?? item['id']}'); if (mounted) setState(() {}); }
    title.dispose(); code.dispose(); assigned.dispose(); details.dispose();
  }
  Widget mapPage() => Column(children: [Padding(padding: const EdgeInsets.all(16), child: Row(children: [const Expanded(child: Text('LIVE LOCATION MAP', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18))), FilledButton.icon(onPressed: busy ? null : locate, icon: const Icon(Icons.my_location), label: const Text('LOCATE NOW'))])), Expanded(child: FlutterMap(mapController: mapController, options: MapOptions(initialCenter: position == null ? const LatLng(0.3476, 32.5825) : LatLng(position!.latitude, position!.longitude), initialZoom: position == null ? 11 : 16), children: [TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.bamunanika.admin'), if (position != null) MarkerLayer(markers: [Marker(point: LatLng(position!.latitude, position!.longitude), width: 54, height: 54, child: const Icon(Icons.location_pin, color: accent, size: 48))]), const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap contributors')])])), Padding(padding: const EdgeInsets.all(10), child: Text(gpsStatus, style: const TextStyle(color: muted, fontSize: 11))) ]);
  Future<void> registerThisDevice() async {
    final name = TextEditingController(text: devices.where((d) => d['id'] == localDeviceId).isEmpty ? 'This device' : '${devices.firstWhere((d) => d['id'] == localDeviceId)['name']}');
    final saved = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Register this device'),
      content: TextField(controller: name, autofocus: true, decoration: const InputDecoration(labelText: 'Device name', hintText: 'e.g. Admin phone')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(ctx, name.text.trim().isNotEmpty), child: const Text('SAVE DEVICE'))],
    ));
    if (saved == true) {
      final index = devices.indexWhere((d) => d['id'] == localDeviceId);
      final entry = {'id': localDeviceId, 'name': name.text.trim(), 'platform': Platform.operatingSystem, 'registered': index < 0 ? DateTime.now().toIso8601String() : devices[index]['registered'], 'updated': DateTime.now().toIso8601String(), 'status': 'THIS INSTALLATION'};
      if (index < 0) { devices.insert(0, entry); } else { devices[index] = entry; }
      await DB.save('devices', devices); await logActivity('DEVICE REGISTERED/UPDATED', name.text.trim());
      if (mounted) setState(() {});
      notify('This installation is registered locally. It is not yet linked to other phones.');
    }
    name.dispose();
  }
  Future<void> removeLocalDevice() async {
    if (!await confirmDelete('this local device registration')) return;
    devices.removeWhere((d) => d['id'] == localDeviceId);
    await DB.save('devices', devices); await logActivity('DEVICE UNREGISTERED', localDeviceId);
    if (mounted) setState(() {});
  }
  Widget devicePage() => _page([
    _heading('Device tools', 'Manage this installation and use permission-based camera and microphone tools.'),
    _section('This device registration', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(devices.any((d) => d['id'] == localDeviceId) ? 'REGISTERED • ${devices.firstWhere((d) => d['id'] == localDeviceId)['name']}' : 'NOT REGISTERED', style: TextStyle(color: devices.any((d) => d['id'] == localDeviceId) ? accent : Colors.orangeAccent, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6), SelectableText('Local device ID: $localDeviceId', style: const TextStyle(color: muted, fontSize: 11)),
      Text('Platform: ${Platform.operatingSystem} • Stored registrations: ${devices.length}', style: const TextStyle(color: muted, fontSize: 11)),
      const SizedBox(height: 10), Wrap(spacing: 8, children: [FilledButton.icon(onPressed: registerThisDevice, icon: const Icon(Icons.phonelink_setup), label: Text(devices.any((d) => d['id'] == localDeviceId) ? 'EDIT DEVICE NAME' : 'REGISTER THIS DEVICE')), if (devices.any((d) => d['id'] == localDeviceId)) TextButton.icon(onPressed: removeLocalDevice, icon: const Icon(Icons.delete_outline), label: const Text('UNREGISTER'))]),
      const Text('This is a local installation registry only. Remote phone registration, authentication and live location sharing require a configured backend and a companion app installed with the other device owner’s consent.', style: TextStyle(color: muted, fontSize: 11, height: 1.4)),
    ])),
    const SizedBox(height: 14),
    _section('Camera capture', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(Platform.isWindows ? 'Choose an image file on Windows and copy it into the app media folder.' : 'Open the device camera, capture a photo and copy it into the app media folder.', style: const TextStyle(color: muted)), const SizedBox(height: 12), Wrap(spacing: 10, children: [FilledButton.icon(onPressed: capturePhoto, icon: const Icon(Icons.camera_alt), label: const Text('OPEN CAMERA')), OutlinedButton.icon(onPressed: () async { await refreshPermissionStatuses(); if (mounted) setState(() => mediaStatus = 'Camera: $cameraPermissionStatus • Microphone: $microphonePermissionStatus'); }, icon: const Icon(Icons.verified_user), label: const Text('CHECK PERMISSIONS'))]), if (latestPhoto != null) Padding(padding: const EdgeInsets.only(top: 12), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(latestPhoto!), height: 220, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Text('Photo file not available on this device.'))))])),
    const SizedBox(height: 14),
    _section('Audio recording', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(recording ? 'Recording is active. Press STOP to finish and save.' : 'Record an audio note using the device microphone.', style: const TextStyle(color: muted)), const SizedBox(height: 12), Wrap(spacing: 10, children: [FilledButton.icon(onPressed: recording ? null : startRecording, icon: const Icon(Icons.fiber_manual_record), label: const Text('START RECORDING')), OutlinedButton.icon(onPressed: recording ? stopRecording : null, icon: const Icon(Icons.stop), label: const Text('STOP & SAVE'))]), if (latestAudio != null) SelectableText('Saved audio: $latestAudio', style: const TextStyle(color: accent, fontSize: 11))])),
    const SizedBox(height: 14), _section('Device tool status', Text(mediaStatus, style: const TextStyle(color: muted))),
    const SizedBox(height: 12), const Text('If Android denies permission, open Settings → Apps → BAMUNANIKA ADMIN → Permissions and allow Camera and Microphone. Hardware availability and Android privacy controls can still prevent access.', style: TextStyle(color: muted, fontSize: 11, height: 1.4)),
  ]);
  Future<void> shareMedia(Map<String, dynamic> item) async {
    final path = '${item['path'] ?? ''}';
    if (path.isEmpty || !await File(path).exists()) { notify('The media file is missing from this device.'); return; }
    try { await Share.shareXFiles([XFile(path)], text: 'BAMUNANIKA ADMIN • ${item['type'] ?? 'MEDIA'}'); }
    catch (e) { notify('Could not share this media file: $e'); }
  }
  Future<void> deleteMedia(Map<String, dynamic> item) async {
    if (!await confirmDelete('this media record and its local file')) return;
    final path = '${item['path'] ?? ''}';
    try { if (path.isNotEmpty && await File(path).exists()) await File(path).delete(); } catch (e) { notify('Could not delete media file: $e'); return; }
    media.removeWhere((m) => item['id'] != null ? m['id'] == item['id'] : identical(m, item)); await DB.save('media', media);
    await logActivity('MEDIA DELETED', '${item['name'] ?? path}');
    if (mounted) setState(() {});
  }
  Widget recordsPage() => _page([
    _heading('Media records', 'View, share and remove photos and audio files saved by this installation.'),
    if (media.isEmpty) _section('Media register', const Text('No media has been captured.', style: TextStyle(color: muted)))
    else ...media.map((m) => _section('${m['type'] ?? 'MEDIA'}  •  ${m['time'] ?? ''}', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('${m['name'] ?? (m['path'] ?? '').toString().split(Platform.pathSeparator).last}', style: const TextStyle(fontWeight: FontWeight.bold)),
      SelectableText('${m['path'] ?? ''}', style: const TextStyle(color: muted, fontSize: 10)),
      if (m['type'] == 'PHOTO' && File('${m['path']}').existsSync()) Padding(padding: const EdgeInsets.only(top: 8), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File('${m['path']}'), height: 180, fit: BoxFit.contain))),
      Wrap(spacing: 8, children: [OutlinedButton.icon(onPressed: () => shareMedia(m), icon: const Icon(Icons.share, size: 16), label: const Text('SHARE FILE')), TextButton.icon(onPressed: () => deleteMedia(m), icon: const Icon(Icons.delete_outline, size: 16), label: const Text('DELETE'))]),
    ])))
  ]);
  Widget activityPage() => _page([
    _heading('Audit activity', 'A local record of administrative changes made on this installation. Newest events appear first.'),
    if (activity.isEmpty) _section('Activity log', const Text('No recorded activity yet. Actions such as creating guests, editing cases and capturing media will appear here.', style: TextStyle(color: muted)))
    else ...activity.map((a) => _section('${a['action'] ?? 'EVENT'}  •  ${a['time'] ?? ''}', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${a['detail'] ?? ''}'), const SizedBox(height: 4), Text('Device: ${a['deviceId'] ?? 'Unknown'}', style: const TextStyle(color: muted, fontSize: 10))])))
  ]);
  Future<void> guestDialog() async {
    final name = TextEditingController(), phone = TextEditingController(), email = TextEditingController(), address = TextEditingController(), notes = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Register guest'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Full name *')), TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone number *')), TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email')), TextField(controller: address, decoration: const InputDecoration(labelText: 'Address / area')), TextField(controller: notes, maxLines: 2, decoration: const InputDecoration(labelText: 'Additional notes'))])), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL')), FilledButton(onPressed: () { if (name.text.trim().isNotEmpty && phone.text.trim().isNotEmpty) { addGuest({'name': name.text.trim(), 'phone': phone.text.trim(), 'email': email.text.trim(), 'address': address.text.trim(), 'notes': notes.text.trim()}); Navigator.pop(context); } else { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter the guest name and phone number.'))); } }, child: const Text('SAVE GUEST'))]));
  }
  Future<void> caseDialog() async {
    final title = TextEditingController(), details = TextEditingController(), code = TextEditingController(), assigned = TextEditingController(); String category = 'General', priority = 'Normal';
    await showDialog(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, refresh) => AlertDialog(title: const Text('Create case'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'Case title *')), TextField(controller: code, decoration: const InputDecoration(labelText: 'Guest registration code')), DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Category'), items: ['General', 'Safety', 'Incident', 'Support', 'Other'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => refresh(() => category = v ?? 'General')), DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'Priority'), items: ['Low', 'Normal', 'High', 'Urgent'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => refresh(() => priority = v ?? 'Normal')), TextField(controller: assigned, decoration: const InputDecoration(labelText: 'Assigned to')), TextField(controller: details, maxLines: 3, decoration: const InputDecoration(labelText: 'Details / action notes'))])), actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')), FilledButton(onPressed: () { if (title.text.trim().isNotEmpty) { addCase({'title': title.text.trim(), 'guestCode': code.text.trim(), 'category': category, 'priority': priority, 'assigned': assigned.text.trim(), 'details': details.text.trim()}); Navigator.pop(dialogContext); } else { ScaffoldMessenger.of(dialogContext).showSnackBar(const SnackBar(content: Text('Enter a case title before saving.'))); } }, child: const Text('SAVE CASE'))])));
  }
  @override void dispose() { locationSubscription?.cancel(); recorder.dispose(); super.dispose(); }
}

Widget _glass(Widget child) => Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF202A34), Color(0xF009111A), Color(0xFF05080D), Color(0xFF111B25)]), borderRadius: BorderRadius.circular(18), border: Border.all(color: line, width: 1.35), boxShadow: const [BoxShadow(color: Color(0x558BD9FF), blurRadius: 24, spreadRadius: -12, offset: Offset(0, 4)), BoxShadow(color: Color(0xCC000000), blurRadius: 26, offset: Offset(0, 14)), BoxShadow(color: Color(0x66FFFFFF), blurRadius: 1, spreadRadius: -1, offset: Offset(-1, -2))]), child: child);
class HolographicCore extends StatefulWidget {
  final double size;
  const HolographicCore({super.key, this.size = 150});
  @override State<HolographicCore> createState() => _HolographicCoreState();
}
class _HolographicCoreState extends State<HolographicCore> with SingleTickerProviderStateMixin {
  late final AnimationController _spin = AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();
  @override void dispose() { _spin.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => AnimatedBuilder(animation: _spin, builder: (_, __) => SizedBox(width: widget.size, height: widget.size, child: Stack(alignment: Alignment.center, children: [
    Container(width: widget.size * .48, height: widget.size * .48, decoration: BoxDecoration(shape: BoxShape.circle, gradient: const RadialGradient(colors: [Color(0xFF1DFFFF), Color(0xFF087C9B), Color(0xFF041421)]), boxShadow: [BoxShadow(color: accent.withOpacity(.75), blurRadius: 28, spreadRadius: 2)])),
    Transform.rotate(angle: _spin.value * math.pi * 2, child: Container(width: widget.size * .92, height: widget.size * .38, decoration: BoxDecoration(border: Border.all(color: accent.withOpacity(.9), width: 1.5), borderRadius: BorderRadius.all(Radius.elliptical(widget.size, widget.size * .4)), boxShadow: [BoxShadow(color: accent.withOpacity(.25), blurRadius: 12)]))),
    Transform.rotate(angle: -_spin.value * math.pi * 2 * .7, child: Container(width: widget.size * .72, height: widget.size * .72, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: accent.withOpacity(.8), width: 1.2)))),
    Icon(Icons.hub_rounded, color: Colors.white.withOpacity(.9), size: widget.size * .22),
  ])));
}

class Brand extends StatelessWidget { const Brand({super.key}); @override Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: const Color(0xFF101820), borderRadius: BorderRadius.circular(12), border: Border.all(color: line)), child: const Icon(Icons.shield_moon_rounded, color: accent)), const SizedBox(width: 10), const Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [Text('BAMUNANIKA V9', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1, fontSize: 13, color: accent)), Text('TACTICAL • 3D COMMAND CENTER', style: TextStyle(color: muted, fontSize: 9, letterSpacing: 1.2))])]); }
