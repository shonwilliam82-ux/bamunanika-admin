/// Firebase integration is deliberately disabled until project credentials,
/// security rules, and authenticated device enrolment are supplied.
/// The app remains fully usable in local-only mode without Firebase.
class FirebaseService {
  static bool get isReady => false;
  static Future<void> initializeIfConfigured() async {
    // No Firebase options are bundled in this development source.
  }
}
