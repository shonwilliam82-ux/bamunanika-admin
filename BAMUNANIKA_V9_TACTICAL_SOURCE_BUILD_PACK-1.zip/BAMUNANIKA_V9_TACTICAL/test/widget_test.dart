import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:bamunanika_v9_tactical/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    final dbPath = '${Directory.systemTemp.path}${Platform.pathSeparator}bamunanika_v9_test.db';
    final dbFile = File(dbPath);
    if (await dbFile.exists()) await dbFile.delete();
    await DB.initialize(databasePath: dbPath);
  });

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('Local data and administrator security', () {
    test('administrator passcode is stored as a salted hash', () async {
      await DB.setPin('StrongPass123');
      final stored = await DB.pin();

      expect(stored, isNotNull);
      expect(stored, startsWith('sha256:'));
      expect(stored, isNot(contains('StrongPass123')));
      expect(await DB.verifyPin('StrongPass123'), isTrue);
      expect(await DB.verifyPin('wrong-passcode'), isFalse);
    });

    test('local records persist and can be read back', () async {
      final records = <Map<String, dynamic>>[
        {'id': 'guest-1', 'name': 'Test Guest', 'phone': '+256700000000'},
      ];

      await DB.save('guests', records);

      expect(await DB.list('guests'), records);
      expect((await DB.counts())['guests'], 1);
    });

    test('SQLite saves replace a collection atomically', () async {
      await DB.save('transaction_test', [{'id': 'stable-1', 'value': 'before'}]);
      await expectLater(
        DB.save('transaction_test', [{'id': 'stable-2', 'invalid': Object()}]),
        throwsA(anything),
      );
      expect(await DB.list('transaction_test'), [
        {'id': 'stable-1', 'value': 'before'},
      ]);
    });

    test('local device identifier remains stable', () async {
      final first = await DB.localDeviceId();
      final second = await DB.localDeviceId();

      expect(first, isNotEmpty);
      expect(second, first);
    });
  });

  testWidgets('consent screen explains local-only operation', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Terms(onYes: _noop)));

    expect(find.text('TERMS & CONSENT'), findsOneWidget);
    expect(find.text('I HAVE READ AND ACCEPT'), findsOneWidget);
    expect(find.textContaining('not uploaded or shared'), findsOneWidget);
  });
}

void _noop() {}
