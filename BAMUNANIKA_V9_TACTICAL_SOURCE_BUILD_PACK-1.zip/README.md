# BAMUNANIKA V9 Tactical Command Center

This ZIP contains the V9-branded Flutter source for Android and Windows 11, plus the GitHub Actions workflow.

To build from GitHub: upload `BAMUNANIKA_V9_TACTICAL_SOURCE_BUILD_PACK.zip` to the repository root, and upload `.github/workflows/build-v9-tactical.yml` from this package into that exact repository folder. The workflow extracts this ZIP, runs Flutter checks, and builds the Android debug APK and Windows portable package.

The V9 dashboard now uses a SQLite database core with transactional saves, schema metadata, stable record IDs, and one-time migration of the older local JSON records. Guest/case/device/media/audit controls are wired to local data operations; camera and audio tools use explicit permissions on Android, and Windows uses image-file selection for the photo register.

Open `BAMUNANIKA_V9_TACTICAL/README.md` for feature scope, limitations, setup, and build instructions. Cloud sync, AI analysis, background multi-device tracking, drone control, face recognition, and live satellite feeds are not configured. The source has not yet been compiled or hardware-tested; the GitHub workflow must pass before APK/EXE delivery.
