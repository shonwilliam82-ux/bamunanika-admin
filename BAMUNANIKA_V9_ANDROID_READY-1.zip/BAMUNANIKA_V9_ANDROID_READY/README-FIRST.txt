BAMUNANIKA V9 ANDROID PROJECT

This package now includes the recovered V9 dashboard HTML at:
app/src/main/assets/index.html

The Android app is a WebView wrapper for that HTML dashboard. It requests device location permission when the dashboard asks for GPS. Location tracking is only available while the app/page is active; this is not a guaranteed Android background tracking service.

BUILD ON GITHUB
1. Open your repository: shonwilliam82-ux/bamunanika-admin
2. Keep all existing V15 files and folders. Do not delete or overwrite them.
3. Upload the CONTENTS of this project ZIP to the repository root, preserving folder paths. If prompted about same-name files, do not overwrite existing V15 files; this package's V9 files are under app/, root Gradle files, and .github/workflows/build-v9-android-apk.yml. Review any conflicts before replacing.
4. Commit the files.
5. Open Actions -> Build BAMUNANIKA V9 Android APK -> Run workflow.
6. Wait for a green successful run, open it, and download artifact BAMUNANIKA-V9-Android-APK.

The APK has not been built yet. A successful GitHub Actions run is required to produce it.

IMPORTANT FEATURE LIMITS
The dashboard includes demo/simulated AI, drone, and facial-recognition panels; these are not connected to real AI services, drones, or a verified identity database. The local demo login/data are not suitable for production security. Do not use this app for covert tracking; obtain clear consent before collecting anyone's location.
