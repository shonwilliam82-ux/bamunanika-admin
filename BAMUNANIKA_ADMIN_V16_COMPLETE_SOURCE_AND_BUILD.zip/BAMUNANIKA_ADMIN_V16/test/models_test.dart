import 'package:flutter_test/flutter_test.dart';
import 'package:bamunanika_admin/models/guest.dart';
import 'package:bamunanika_admin/models/case_record.dart';

void main() {
  test('guest model serializes and restores registration data', () {
    const guest = Guest(id: 'g1', name: 'Test Guest', phone: '+256700000000', registrationCode: 'BAM-ABCD1234');
    final restored = Guest.fromMap('g1', guest.toMap());
    expect(restored.name, 'Test Guest');
    expect(restored.registrationCode, 'BAM-ABCD1234');
  });
  test('case model serializes linked guest and status', () {
    const record = CaseRecord(id: 'c1', title: 'Test case', details: 'Details', guestId: 'g1');
    final restored = CaseRecord.fromMap('c1', record.toMap());
    expect(restored.guestId, 'g1');
    expect(restored.status, 'open');
  });
}
