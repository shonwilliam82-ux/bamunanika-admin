# BAMUNANIKA ADMIN V16 — unified Flutter source project

A single Flutter codebase targeting Android and Windows 11. This is the **complete current source baseline and reproducible build package**, not a claim that a signed production app or deployed cloud service already exists.

## Included application modules
- Terms and consent gate before first use.
- Local administrator passcode setup/login (salted hash; convenience lock only).
- Responsive dark-glass operations dashboard.
- Guest registration with unique local reference codes.
- Case creation, assignment, priority and status updates.
- OpenStreetMap view and on-demand current-device GPS fix.
- Camera capture and user-started microphone audio notes, subject to OS permission.
- Local media register.
- Firebase Authentication/Firestore/Storage service scaffolding, security rules and server-side registration-code function.
- Android permission manifest template, Windows Inno Setup script, CI build workflow, tests and release documentation.

## Current limitations — read before deployment
- Guest/case/media records are stored locally on the device. Firebase service methods exist but are not wired into the current dashboard forms.
- Firebase is disabled by default. No project credentials, admin accounts, custom claims, or deployed functions are supplied.
- The location-sharing control is a local preview only. No multi-phone live tracking or remote location subscription is active.
- No guest companion app, remote camera/microphone, background location service, push messaging, or phone app-link automation is included.
- Local passcode storage is a development convenience lock, not production authentication or secure credential storage.
- The project has not been built or tested on physical Android hardware or Windows 11 in this workspace. CI must pass and devices must be tested before release.

## Build
See [`docs/BUILD_AND_RELEASE.md`](docs/BUILD_AND_RELEASE.md). The GitHub Actions workflow `.github/workflows/build-v16.yml` generates platform scaffolding, formats, analyzes, tests and builds Android and Windows artifacts. It also packages a Windows installer.

## Project layout
- `lib/` Flutter application, models and services
- `assets/branding/` app branding asset
- `platform-templates/android/` Android manifest with required permissions
- `firebase/` rules, config and callable function source
- `installer/` Inno Setup script
- `.github/workflows/` reproducible CI builds
- `docs/` architecture, privacy, setup and release checklists

## Safety
Location is requested only after a user presses the location button and grants OS permission. Camera and microphone actions are user initiated. No covert tracking or recording is implemented. See [`docs/SECURITY_AND_PRIVACY.md`](docs/SECURITY_AND_PRIVACY.md).
