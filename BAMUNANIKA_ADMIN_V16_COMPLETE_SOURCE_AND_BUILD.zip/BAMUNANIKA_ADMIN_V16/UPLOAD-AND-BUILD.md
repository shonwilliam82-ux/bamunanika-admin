# Build BAMUNANIKA ADMIN V16 from GitHub Mobile

This ZIP contains the Flutter source project and a GitHub Actions workflow. It is **not itself an APK or Windows installer**.

## Upload
1. Open `github.com/shonwilliam82-ux/bamunanika-admin` in your browser or GitHub app.
2. Extract this ZIP on a computer if possible, then upload/commit the **contents of `BAMUNANIKA_ADMIN_V16`** into the repository root. Keep the `.github/workflows/build-v16.yml` path intact. On a phone, GitHub's web upload page may be easier than the mobile app for uploading a whole folder.
3. Commit to the `main` branch.

## Run the build
1. Open the repository's **Actions** tab.
2. Select **Build BAMUNANIKA ADMIN V16**.
3. Tap **Run workflow** and choose `main`.
4. Wait for both jobs to finish. A green check means the workflow completed; it does not replace installing and testing on your own devices.
5. Open the completed run, scroll to **Artifacts**, and download:
   - `BAMUNANIKA-ADMIN-V16-ANDROID-APK`
   - `BAMUNANIKA-ADMIN-V16-WINDOWS-PORTABLE`
   - `BAMUNANIKA-ADMIN-V16-WINDOWS-INSTALLER`

## Important limits
- The current source is a V16 development baseline, not the pasted V8.5.1 HTML converted byte-for-byte.
- Location in this build is an on-demand fix from the device running the app. Multi-phone live tracking is not yet enabled.
- Firebase credentials and project setup are not included. Cloud sync/authentication must be configured before use across devices.
- The admin passcode is a local prototype mechanism, not production-grade multi-user security.
- Do not use this build for covert tracking or recording. Location sharing must be explicitly enabled by the device owner and visibly stoppable.
