import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../firebase_options.dart';

/// Firebase integration layer. Firebase is deliberately opt-in until the app
/// is configured with real project credentials using FlutterFire CLI.
class FirebaseService {
  FirebaseService._();
  static bool get isReady => Firebase.apps.isNotEmpty;
  static Future<void> initializeIfConfigured() async {
    const enabled = bool.fromEnvironment('BAMUNANIKA_FIREBASE', defaultValue: false);
    if (!enabled) return;
    try {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    } on FirebaseException catch (e) {
      // Keep local mode available; the UI must not imply cloud sync is active.
      // ignore: avoid_print
      print('Firebase initialization failed: ${e.code}: ${e.message}');
    }
  }
  static FirebaseAuth get auth { _requireReady(); return FirebaseAuth.instance; }
  static FirebaseFirestore get db { _requireReady(); return FirebaseFirestore.instance; }
  static void _requireReady() {
    if (!isReady) throw StateError('Firebase is not configured. Run flutterfire configure and enable BAMUNANIKA_FIREBASE.');
  }
  static Future<UserCredential> signIn(String email, String password) async =>
      auth.signInWithEmailAndPassword(email: email.trim(), password: password);
  static Future<UserCredential> register(String email, String password) async =>
      auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
  static Future<void> signOut() async { _requireReady(); await FirebaseAuth.instance.signOut(); }
  static Stream<User?> authChanges() { _requireReady(); return auth.authStateChanges(); }

  /// Registration creates a profile owned by the authenticated user. Admin
  /// role is never accepted from a client-provided field.
  static Future<void> saveGuest({required String uid, required String name,
    required String phone, required String registrationCode}) async {
    await db.collection('guests').doc(uid).set({
      'name': name.trim(), 'phone': phone.trim(), 'registrationCode': registrationCode,
      'createdAt': FieldValue.serverTimestamp(), 'createdBy': auth.currentUser!.uid,
      'status': 'active',
    }, SetOptions(merge: true));
  }
  static Stream<QuerySnapshot<Map<String, dynamic>>> watchGuests() =>
      db.collection('guests').orderBy('createdAt', descending: true).snapshots();
  static Future<void> createCase({required String title, required String details,
    required String guestId, required String caseId}) async {
    await db.collection('cases').doc(caseId).set({
      'title': title.trim(), 'details': details.trim(), 'guestId': guestId,
      'status': 'open', 'createdAt': FieldValue.serverTimestamp(),
      'createdBy': auth.currentUser!.uid,
    });
  }
  static Stream<QuerySnapshot<Map<String, dynamic>>> watchCases() =>
      db.collection('cases').orderBy('createdAt', descending: true).snapshots();
  /// Location updates must be explicitly enabled by the device owner. Store
  /// only while the visible sharing control is on; stop by deleting live doc.
  static Future<void> publishOwnLocation({required double latitude,
    required double longitude, required bool sharingEnabled}) async {
    final user = auth.currentUser;
    if (user == null) throw StateError('Sign in before sharing location.');
    final ref = db.collection('liveLocations').doc(user.uid);
    if (!sharingEnabled) { await ref.delete(); return; }
    await ref.set({'uid': user.uid, 'latitude': latitude, 'longitude': longitude,
      'updatedAt': FieldValue.serverTimestamp(), 'sharingEnabled': true});
  }
  static Stream<QuerySnapshot<Map<String, dynamic>>> watchConsentedLocations() =>
      db.collection('liveLocations').where('sharingEnabled', isEqualTo: true).snapshots();
  static Future<String> generateRegistrationCode() async {
    final user = auth.currentUser;
    if (user == null) throw StateError('Sign in before requesting a registration code.');
    const project = String.fromEnvironment('FIREBASE_PROJECT_ID');
    const region = String.fromEnvironment('FIREBASE_FUNCTIONS_REGION', defaultValue: 'us-central1');
    final token = await user.getIdToken();
    final uri = Uri.parse('https://${region}-${project}.cloudfunctions.net/createGuestRegistrationCode');
    final response = await http.post(uri, headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ${token}'}, body: jsonEncode({'data': {}}));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError('Registration code service failed (${response.statusCode}).');
    }
    final payload = jsonDecode(response.body) as Map<String, dynamic>;
    return ((payload['result'] ?? payload['data']) as Map<String, dynamic>)['code'] as String;
  }
}
