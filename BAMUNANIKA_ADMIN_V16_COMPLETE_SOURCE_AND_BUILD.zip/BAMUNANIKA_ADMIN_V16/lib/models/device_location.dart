class DeviceLocation {
  const DeviceLocation({required this.uid, required this.latitude,
    required this.longitude, required this.updatedAt});
  final String uid; final double latitude, longitude; final DateTime? updatedAt;
  factory DeviceLocation.fromMap(Map<String, dynamic> map) => DeviceLocation(
    uid: map['uid'] as String? ?? '', latitude: (map['latitude'] as num).toDouble(),
    longitude: (map['longitude'] as num).toDouble(),
    updatedAt: (map['updatedAt'] as dynamic)?.toDate() as DateTime?);
}
