class CaseRecord {
  const CaseRecord({required this.id, required this.title, required this.details,
    required this.guestId, this.status = 'open'});
  final String id, title, details, guestId, status;
  Map<String, Object?> toMap() => {'id': id, 'title': title, 'details': details,
    'guestId': guestId, 'status': status};
  factory CaseRecord.fromMap(String id, Map<String, dynamic> map) => CaseRecord(
    id: id, title: map['title'] as String? ?? '', details: map['details'] as String? ?? '',
    guestId: map['guestId'] as String? ?? '', status: map['status'] as String? ?? 'open');
}
