import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'services/firebase_service.dart';

const bg = Color(0xFF070B10);
const panel = Color(0xE817222D);
const panel2 = Color(0xFF101923);
const accent = Color(0xFF4DE2C3);
const muted = Color(0xFF9BAABA);
const line = Color(0x243CE8D0);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseService.initializeIfConfigured();
  runApp(const BamunanikaApp());
}

class BamunanikaApp extends StatelessWidget {
  const BamunanikaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'BAMUNANIKA ADMIN V16', debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: accent, surface: panel),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel2,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: line)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: line)),
      ),
    ),
    home: const Gate(),
  );
}

class DB {
  static Future<SharedPreferences> get p => SharedPreferences.getInstance();
  static Future<bool> terms() async => (await p).getBool('terms') ?? false;
  static Future<void> accept() async => (await p).setBool('terms', true);
  static Future<String?> pin() async => (await p).getString('admin_pin');
  static Future<void> setPin(String value) async {
    final random = math.Random.secure();
    final salt = List<int>.generate(16, (_) => random.nextInt(256));
    final digest = sha256.convert([...salt, ...utf8.encode(value)]).toString();
    await (await p).setString('admin_pin', 'sha256:${base64Encode(salt)}:$digest');
  }
  static Future<bool> verifyPin(String value) async {
    final stored = await pin();
    if (stored == null) return false;
    if (!stored.startsWith('sha256:')) {
      // Migrate an older prototype's plain local passcode on successful login.
      if (stored != value) return false;
      await setPin(value);
      return true;
    }
    final parts = stored.split(':');
    if (parts.length != 3) return false;
    final salt = base64Decode(parts[1]);
    final digest = sha256.convert([...salt, ...utf8.encode(value)]).toString();
    return digest == parts[2];
  }
  static Future<List<Map<String, dynamic>>> list(String k) async {
    final s = (await p).getString(k); if (s == null) return [];
    try { return (jsonDecode(s) as List).cast<Map<String, dynamic>>(); } catch (_) { return []; }
  }
  static Future<void> save(String k, List<Map<String, dynamic>> v) async => (await p).setString(k, jsonEncode(v));
}

class Gate extends StatefulWidget { const Gate({super.key}); @override State<Gate> createState() => _GateState(); }
class _GateState extends State<Gate> {
  bool? accepted;
  @override void initState() { super.initState(); DB.terms().then((v) { if (mounted) setState(() => accepted = v); }); }
  @override Widget build(BuildContext context) {
    if (accepted == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return accepted! ? const Login() : Terms(onYes: () async { await DB.accept(); if (mounted) setState(() => accepted = true); });
  }
}

class Terms extends StatelessWidget {
  final VoidCallback onYes;
  const Terms({super.key, required this.onYes});
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 620), child: Padding(padding: const EdgeInsets.all(22), child: _glass(Column(
      mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Brand(), const SizedBox(height: 24), const Text('TERMS & CONSENT', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12), const Text('• A location fix is requested only when the device owner selects LOCATE NOW.\n• Location is not uploaded or shared with another device in this development build.\n• Camera and microphone are accessed only after the user starts those tools and grants permission.\n• No covert tracking or recording is permitted.\n• Guest, case and media indexes are stored locally; cloud sync is not yet connected.\n• Before any future sharing feature is enabled, the device owner must be informed, actively opt in, see a persistent sharing status, and be able to stop sharing.' , style: TextStyle(color: muted, height: 1.5)),
        const SizedBox(height: 20), SizedBox(width: double.infinity, child: FilledButton(onPressed: onYes, child: const Text('I HAVE READ AND ACCEPT'))),
      ],
    ))),
  )));
}

class Login extends StatefulWidget { const Login({super.key}); @override State<Login> createState() => _LoginState(); }
class _LoginState extends State<Login> {
  final ctrl = TextEditingController(); bool setup = false; bool ready = false; String error = '';
  @override void initState() { super.initState(); DB.pin().then((v) { if (mounted) setState(() { setup = v == null; ready = true; }); }); }
  Future<void> go() async {
    final value = ctrl.text.trim(); if (value.length < 6) { setState(() => error = 'Use at least 6 characters.'); return; }
    if (setup) await DB.setPin(value);
    if (await DB.verifyPin(value)) { if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home())); }
    else { setState(() => error = 'Incorrect passcode.'); }
  }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460), child: Padding(padding: const EdgeInsets.all(22), child: _glass(Column(
    mainAxisSize: MainAxisSize.min, children: [const Brand(), const SizedBox(height: 26), Text(setup ? 'CREATE ADMIN PASSCODE' : 'ADMIN SIGN IN', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.1)), const SizedBox(height: 14),
      TextField(controller: ctrl, obscureText: true, decoration: const InputDecoration(labelText: 'Passcode (minimum 6 characters)')),
      if (error.isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(error, style: const TextStyle(color: Colors.redAccent))),
      const SizedBox(height: 14), SizedBox(width: double.infinity, child: FilledButton(onPressed: ready ? go : null, child: const Text('CONTINUE'))),
      const SizedBox(height: 12), const Text('Local prototype security. A production multi-user admin account requires a configured secure backend.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11)),
    ],
  ))))));
  @override void dispose() { ctrl.dispose(); super.dispose(); }
}

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState() => _HomeState(); }
class _HomeState extends State<Home> {
  int tab = 0;
  List<Map<String, dynamic>> guests = [], cases = [], media = [];
  Position? position; bool sharing = false, busy = false, recording = false;
  String gpsStatus = 'Waiting for location permission', mediaStatus = 'Camera and microphone are idle';
  String? latestPhoto, latestAudio;
  final picker = ImagePicker(); final recorder = AudioRecorder();
  @override void initState() { super.initState(); load(); }
  Future<void> load() async { guests = await DB.list('guests'); cases = await DB.list('cases'); media = await DB.list('media'); if (mounted) setState(() {}); }
  void notify(String s) { if (!mounted) return; setState(() => gpsStatus = s); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s))); }
  Future<bool> locationPermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) { notify('GPS is switched off. Turn on Location in Android settings.'); return false; }
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.deniedForever || p == LocationPermission.denied) { notify('Location permission denied. Allow it in App info > Permissions.'); return false; }
    return true;
  }
  Future<void> locate() async {
    if (busy) return; setState(() { busy = true; gpsStatus = 'Requesting GPS fix…'; });
    try {
      if (!await locationPermission()) return;
      final service = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 25)));
      if (!mounted) return; setState(() { position = service; gpsStatus = 'GPS FIX ACQUIRED • ${service.latitude.toStringAsFixed(6)}, ${service.longitude.toStringAsFixed(6)}'; });
    } catch (e) { notify('Could not get GPS fix: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> toggleSharing(bool value) async {
    if (!value) { setState(() => sharing = false); notify('Local sharing preview stopped. No remote location session was active.'); return; }
    if (!await locationPermission()) return;
    await locate(); if (position != null && mounted) { setState(() => sharing = true); notify('Local sharing preview is ON. No location has been sent to other devices.'); }
  }
  Future<void> addGuest(Map<String, String> fields) async {
    final id = const Uuid().v4(); final code = 'BAM-${const Uuid().v4().substring(0, 8).toUpperCase()}';
    guests.insert(0, {'id': id, ...fields, 'code': code, 'created': DateTime.now().toIso8601String()});
    await DB.save('guests', guests); if (mounted) setState(() {}); notify('Guest saved on this device. Code: $code');
  }
  Future<void> addCase(Map<String, String> fields) async {
    cases.insert(0, {'id': const Uuid().v4(), ...fields, 'status': 'OPEN', 'created': DateTime.now().toIso8601String()});
    await DB.save('cases', cases); if (mounted) setState(() {}); notify('Case saved locally.');
  }
  Future<void> capturePhoto() async {
    final permission = await Permission.camera.request();
    if (!permission.isGranted) { setState(() => mediaStatus = 'Camera permission denied. Enable Camera in Android App permissions.'); return; }
    try {
      final file = await picker.pickImage(source: ImageSource.camera, imageQuality: 88);
      if (file == null) { setState(() => mediaStatus = 'Camera closed without taking a photo.'); return; }
      latestPhoto = file.path; media.insert(0, {'type': 'PHOTO', 'path': file.path, 'time': DateTime.now().toIso8601String()}); await DB.save('media', media);
      if (mounted) setState(() => mediaStatus = 'Photo captured and saved on this device: ${file.name}');
    } catch (e) { if (mounted) setState(() => mediaStatus = 'Camera failed: $e'); }
  }
  Future<void> startRecording() async {
    final permission = await Permission.microphone.request();
    if (!permission.isGranted) { setState(() => mediaStatus = 'Microphone permission denied. Enable Microphone in Android App permissions.'); return; }
    try {
      if (!await recorder.hasPermission()) { setState(() => mediaStatus = 'Recorder cannot access microphone. Check Android permission.'); return; }
      final dir = await getApplicationDocumentsDirectory(); final path = '${dir.path}/bamunanika_audio_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
      if (mounted) setState(() { recording = true; mediaStatus = 'RECORDING • Tap STOP to save the audio file.'; });
    } catch (e) { if (mounted) setState(() => mediaStatus = 'Microphone failed: $e'); }
  }
  Future<void> stopRecording() async {
    try {
      final path = await recorder.stop(); if (path != null) { latestAudio = path; media.insert(0, {'type': 'AUDIO', 'path': path, 'time': DateTime.now().toIso8601String()}); await DB.save('media', media); }
      if (mounted) setState(() { recording = false; mediaStatus = path == null ? 'Recording stopped.' : 'Audio saved on this device: $path'; });
    } catch (e) { if (mounted) setState(() { recording = false; mediaStatus = 'Could not stop recording: $e'; }); }
  }
  @override Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 900;
    final pages = [overview(), guestsPage(), casesPage(), mapPage(), devicePage(), recordsPage()];
    const labels = ['Dashboard', 'Guests', 'Cases', 'Live Map', 'Device Tools', 'Records'];
    const icons = [Icons.dashboard_rounded, Icons.people_alt_rounded, Icons.folder_copy_rounded, Icons.map_rounded, Icons.devices_rounded, Icons.history_rounded];
    return Scaffold(
      appBar: AppBar(title: const Brand(), actions: [IconButton(tooltip: 'Refresh records', onPressed: load, icon: const Icon(Icons.refresh)), const SizedBox(width: 8)]),
      body: Row(children: [
        if (wide) Container(width: 224, decoration: const BoxDecoration(color: Color(0xFF0B121A), border: Border(right: BorderSide(color: line))), child: Column(children: [const SizedBox(height: 12), for (var i = 0; i < labels.length; i++) _navItem(i, labels[i], icons[i]), const Spacer(), Padding(padding: const EdgeInsets.all(14), child: _statusChip('LOCAL DEVICE MODE', Icons.shield_outlined)), const SizedBox(height: 10)])),
        Expanded(child: pages[tab]),
      ]),
      bottomNavigationBar: wide ? null : NavigationBar(backgroundColor: panel2, selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: List.generate(labels.length, (i) => NavigationDestination(icon: Icon(icons[i]), label: labels[i]))),
    );
  }
  Widget _navItem(int index, String label, IconData icon) => Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), child: ListTile(selected: tab == index, selectedTileColor: const Color(0xFF15312F), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), leading: Icon(icon, color: tab == index ? accent : muted), title: Text(label, style: TextStyle(color: tab == index ? Colors.white : muted, fontWeight: tab == index ? FontWeight.bold : FontWeight.normal)), onTap: () => setState(() => tab = index)));
  Widget _statusChip(String label, IconData icon) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(color: const Color(0xFF102A29), borderRadius: BorderRadius.circular(30), border: Border.all(color: line)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 15, color: accent), const SizedBox(width: 7), Text(label, style: const TextStyle(fontSize: 10, letterSpacing: 1, color: accent, fontWeight: FontWeight.bold))]));
  Widget _page(List<Widget> children) => LayoutBuilder(builder: (context, c) => ListView(padding: EdgeInsets.all(c.maxWidth > 1000 ? 28 : 16), children: [ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1500), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children))]));
  Widget _heading(String title, String subtitle) => Padding(padding: const EdgeInsets.only(bottom: 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title.toUpperCase(), style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.1)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(color: muted))]));
  Widget _stat(String title, String value, IconData icon, String foot) => _glass(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: accent), const Spacer(), const Icon(Icons.more_horiz, color: muted)]), const SizedBox(height: 13), Text(value, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)), Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(foot, style: const TextStyle(color: muted, fontSize: 11))]));
  Widget _section(String title, Widget child) => _glass(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1, fontSize: 12, color: accent)), const SizedBox(height: 13), child]));
  Widget overview() => _page([
    _heading('Operations dashboard', 'Unified control centre • BAMUNANIKA ADMIN V16'),
    Wrap(spacing: 12, runSpacing: 12, children: [SizedBox(width: 190, child: _stat('REGISTERED GUESTS', '${guests.length}', Icons.people_alt_outlined, 'Profiles on this device')), SizedBox(width: 190, child: _stat('TOTAL CASES', '${cases.length}', Icons.folder_open, 'Case records stored locally')), SizedBox(width: 190, child: _stat('OPEN CASES', '${cases.where((e) => e['status'] == 'OPEN').length}', Icons.pending_actions, 'Awaiting review')), SizedBox(width: 190, child: _stat('MEDIA RECORDS', '${media.length}', Icons.perm_media_outlined, 'Photos and audio files'))]),
    const SizedBox(height: 14),
    LayoutBuilder(builder: (context, c) { final split = c.maxWidth > 800; final gps = _section('GPS / location control', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Icon(Icons.gps_fixed, color: accent), const SizedBox(width: 8), Expanded(child: Text(position == null ? 'No location fix yet' : 'GPS FIX • ${position!.accuracy.toStringAsFixed(0)} m accuracy', style: const TextStyle(fontWeight: FontWeight.bold)))]), const SizedBox(height: 8), Text(gpsStatus, style: const TextStyle(color: muted, fontSize: 12)), if (position != null) Text('Lat ${position!.latitude.toStringAsFixed(6)}  •  Lon ${position!.longitude.toStringAsFixed(6)}\nUpdated ${position!.timestamp.toLocal()}', style: const TextStyle(fontSize: 12)), SwitchListTile(contentPadding: EdgeInsets.zero, value: sharing, onChanged: toggleSharing, title: const Text('Location sharing (preview only)'), subtitle: const Text('Local preview only — no remote sharing is active in this build', style: TextStyle(color: muted, fontSize: 11))), Wrap(spacing: 8, children: [FilledButton.icon(onPressed: busy ? null : locate, icon: const Icon(Icons.my_location), label: Text(busy ? 'LOCATING…' : 'LOCATE NOW')), OutlinedButton.icon(onPressed: () => setState(() => tab = 3), icon: const Icon(Icons.map_outlined), label: const Text('OPEN MAP'))]) ]));
      final quick = _section('Quick actions', Wrap(spacing: 9, runSpacing: 9, children: [_action('Register guest', Icons.person_add_alt_1, () => setState(() => tab = 1)), _action('Create case', Icons.add_box_outlined, () => setState(() => tab = 2)), _action('Camera', Icons.camera_alt_outlined, capturePhoto), _action('Audio recorder', Icons.mic_none, () => recording ? stopRecording() : startRecording()), _action('View records', Icons.history, () => setState(() => tab = 5))]));
      return split ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: gps), const SizedBox(width: 14), Expanded(child: quick)]) : Column(children: [gps, const SizedBox(height: 14), quick]); }),
    const SizedBox(height: 14),
    _section('System & integration status', Column(children: [ _statusRow('GPS hardware / permission', position == null ? 'NOT FIXED' : 'LOCATION AVAILABLE', position == null ? Colors.orangeAccent : accent), _statusRow('Camera permission workflow', 'ASKED WHEN OPENED', accent), _statusRow('Microphone permission workflow', 'ASKED WHEN RECORDING', accent), _statusRow('Cloud database', FirebaseService.isReady ? 'INITIALIZED — UI SYNC NOT VERIFIED' : 'NOT CONFIGURED', Colors.orangeAccent), _statusRow('Data storage', 'LOCAL DEVICE STORAGE', muted), const SizedBox(height: 8), const Text('Multi-phone tracking is NOT active in this build. It requires Firebase configuration, authenticated device registration, explicit owner consent, visible sharing controls, and a separate guest app. This dashboard does not silently access other phone apps.', style: TextStyle(color: muted, fontSize: 11, height: 1.4)) ])),
  ]);
  Widget _action(String label, IconData icon, VoidCallback fn) => OutlinedButton.icon(onPressed: fn, icon: Icon(icon, size: 18), label: Text(label));
  Widget _statusRow(String label, String value, Color color) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: muted))), Text(value, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: .5))]));
  Widget guestsPage() => _page([_heading('Guest registration', 'Register a person, capture contact details and issue a unique reference code.'), Align(alignment: Alignment.centerLeft, child: FilledButton.icon(onPressed: guestDialog, icon: const Icon(Icons.person_add), label: const Text('REGISTER NEW GUEST'))), const SizedBox(height: 14), if (guests.isEmpty) _section('Guest directory', const Text('No guest profiles registered yet.', style: TextStyle(color: muted))) else ...guests.map((g) => _section('${g['name'] ?? 'Guest'}  •  ${g['code'] ?? ''}', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Phone: ${g['phone'] ?? '—'}'), Text('Email: ${g['email'] ?? '—'}'), Text('Address: ${g['address'] ?? '—'}'), Text('Notes: ${g['notes'] ?? '—'}'), Text('Registered: ${g['created'] ?? '—'}', style: const TextStyle(color: muted, fontSize: 11))]))) ]);
  Widget casesPage() => _page([_heading('Case management', 'Create, review and track case records linked to guest reference codes.'), Align(alignment: Alignment.centerLeft, child: FilledButton.icon(onPressed: caseDialog, icon: const Icon(Icons.add), label: const Text('CREATE NEW CASE'))), const SizedBox(height: 14), if (cases.isEmpty) _section('Case register', const Text('No cases have been created.', style: TextStyle(color: muted))) else ...cases.map((x) => _section('${x['title'] ?? 'Case'}  •  ${x['status'] ?? 'OPEN'}', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Reference: ${x['id'] ?? '—'}', style: const TextStyle(color: muted, fontSize: 11)), Text('Guest code: ${x['guestCode'] ?? '—'}'), Text('Category: ${x['category'] ?? 'General'}  •  Priority: ${x['priority'] ?? 'Normal'}'), Text('${x['details'] ?? ''}'), Text('Assigned to: ${x['assigned'] ?? 'Unassigned'}'), Text('Created: ${x['created'] ?? ''}', style: const TextStyle(color: muted, fontSize: 11)), Wrap(spacing: 8, children: [TextButton(onPressed: () => updateCaseStatus(x, 'IN PROGRESS'), child: const Text('IN PROGRESS')), TextButton(onPressed: () => updateCaseStatus(x, 'CLOSED'), child: const Text('CLOSE CASE'))]) ]))) ]);
  Future<void> updateCaseStatus(Map<String, dynamic> item, String status) async { item['status'] = status; await DB.save('cases', cases); if (mounted) setState(() {}); }
  Widget mapPage() => Column(children: [Padding(padding: const EdgeInsets.all(16), child: Row(children: [const Expanded(child: Text('LIVE LOCATION MAP', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18))), FilledButton.icon(onPressed: busy ? null : locate, icon: const Icon(Icons.my_location), label: const Text('LOCATE NOW'))])), Expanded(child: FlutterMap(options: MapOptions(initialCenter: position == null ? const LatLng(0.3476, 32.5825) : LatLng(position!.latitude, position!.longitude), initialZoom: position == null ? 11 : 16), children: [TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.bamunanika.admin'), if (position != null) MarkerLayer(markers: [Marker(point: LatLng(position!.latitude, position!.longitude), width: 54, height: 54, child: const Icon(Icons.location_pin, color: accent, size: 48))]), const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap contributors')])])), Padding(padding: const EdgeInsets.all(10), child: Text(gpsStatus, style: const TextStyle(color: muted, fontSize: 11))) ]);
  Widget devicePage() => _page([_heading('Device tools', 'Camera and microphone controls. Android asks for permission when each tool is started.'), _section('Camera capture', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Open the device camera, capture a photo and save its file path in the local media register.', style: TextStyle(color: muted)), const SizedBox(height: 12), Wrap(spacing: 10, children: [FilledButton.icon(onPressed: capturePhoto, icon: const Icon(Icons.camera_alt), label: const Text('OPEN CAMERA')), OutlinedButton.icon(onPressed: () async { final s = await Permission.camera.status; if (mounted) setState(() => mediaStatus = 'Camera permission: ${s.name}'); }, icon: const Icon(Icons.verified_user), label: const Text('CHECK PERMISSION'))]), if (latestPhoto != null) Padding(padding: const EdgeInsets.only(top: 12), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(latestPhoto!), height: 220, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Text('Photo file not available on this device.'))))])), const SizedBox(height: 14), _section('Audio recording', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(recording ? 'Recording is active. Press STOP to finish and save.' : 'Record an audio note using the device microphone.', style: const TextStyle(color: muted)), const SizedBox(height: 12), Wrap(spacing: 10, children: [FilledButton.icon(onPressed: recording ? null : startRecording, icon: const Icon(Icons.fiber_manual_record), label: const Text('START RECORDING')), OutlinedButton.icon(onPressed: recording ? stopRecording : null, icon: const Icon(Icons.stop), label: const Text('STOP & SAVE'))]), if (latestAudio != null) SelectableText('Saved audio: $latestAudio', style: const TextStyle(color: accent, fontSize: 11))])), const SizedBox(height: 14), _section('Device tool status', Text(mediaStatus, style: const TextStyle(color: muted))), const SizedBox(height: 12), const Text('If Android denies permission, open Settings → Apps → BAMUNANIKA ADMIN → Permissions and allow Camera and Microphone. Hardware availability and Android privacy controls can still prevent access.', style: TextStyle(color: muted, fontSize: 11, height: 1.4))]);
  Widget recordsPage() => _page([_heading('Media & activity records', 'Photos and audio files captured using this device.'), if (media.isEmpty) _section('Media register', const Text('No media has been captured.', style: TextStyle(color: muted))) else ...media.map((m) => _section('${m['type']}  •  ${m['time']}', SelectableText('${m['path']}', style: const TextStyle(color: muted, fontSize: 11))))]);
  Future<void> guestDialog() async {
    final name = TextEditingController(), phone = TextEditingController(), email = TextEditingController(), address = TextEditingController(), notes = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Register guest'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Full name *')), TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone number *')), TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email')), TextField(controller: address, decoration: const InputDecoration(labelText: 'Address / area')), TextField(controller: notes, maxLines: 2, decoration: const InputDecoration(labelText: 'Additional notes'))])), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL')), FilledButton(onPressed: () { if (name.text.trim().isNotEmpty && phone.text.trim().isNotEmpty) { addGuest({'name': name.text.trim(), 'phone': phone.text.trim(), 'email': email.text.trim(), 'address': address.text.trim(), 'notes': notes.text.trim()}); Navigator.pop(context); } }, child: const Text('SAVE GUEST'))]));
  }
  Future<void> caseDialog() async {
    final title = TextEditingController(), details = TextEditingController(), code = TextEditingController(), assigned = TextEditingController(); String category = 'General', priority = 'Normal';
    await showDialog(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, refresh) => AlertDialog(title: const Text('Create case'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'Case title *')), TextField(controller: code, decoration: const InputDecoration(labelText: 'Guest registration code')), DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Category'), items: ['General', 'Safety', 'Incident', 'Support', 'Other'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => refresh(() => category = v ?? 'General')), DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'Priority'), items: ['Low', 'Normal', 'High', 'Urgent'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => refresh(() => priority = v ?? 'Normal')), TextField(controller: assigned, decoration: const InputDecoration(labelText: 'Assigned to')), TextField(controller: details, maxLines: 3, decoration: const InputDecoration(labelText: 'Details / action notes'))])), actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')), FilledButton(onPressed: () { if (title.text.trim().isNotEmpty) { addCase({'title': title.text.trim(), 'guestCode': code.text.trim(), 'category': category, 'priority': priority, 'assigned': assigned.text.trim(), 'details': details.text.trim()}); Navigator.pop(dialogContext); } }, child: const Text('SAVE CASE'))])));
  }
  @override void dispose() { recorder.dispose(); super.dispose(); }
}

Widget _glass(Widget child) => Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: line), boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 20, offset: Offset(0, 8))]), child: child);
class Brand extends StatelessWidget { const Brand({super.key}); @override Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: const Color(0xFF10322F), borderRadius: BorderRadius.circular(12), border: Border.all(color: line)), child: const Icon(Icons.shield_moon_rounded, color: accent)), const SizedBox(width: 10), const Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [Text('BAMUNANIKA ADMIN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1, fontSize: 13)), Text('V16 • OPERATIONS CONSOLE', style: TextStyle(color: muted, fontSize: 9, letterSpacing: 1.2))])]); }
