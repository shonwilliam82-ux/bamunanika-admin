# Build and release guide

## Requirements
- Flutter stable (Dart version compatible with `pubspec.yaml`)
- Java 17 for Android builds
- Android SDK / command-line tools
- Windows 11 with Visual Studio 2022 Desktop development with C++ workload for native Windows builds
- Inno Setup 6 for the Windows installer

## Android
Run `scripts/prepare-android.sh` from the project root on macOS/Linux or execute the equivalent commands in PowerShell:

```powershell
flutter create --platforms=android .
Copy-Item platform-templates/android/app/src/main/AndroidManifest.xml android/app/src/main/AndroidManifest.xml -Force
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Windows 11
```powershell
flutter create --platforms=windows .
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build windows --release
```

The release folder is `build/windows/x64/runner/Release`. Build the installer by opening `installer/BamunanikaAdmin.iss` in Inno Setup 6 or running `ISCC.exe installer/BamunanikaAdmin.iss` from the repository root. Test the installer on a clean Windows 11 machine.

## Signing
Do not commit keystores, passwords, certificates or signing secrets. Configure Android signing through protected GitHub Actions secrets or a secure local keystore. The default CI artifact is a build output for validation, not a Play Store-ready signed release.

## CI
`.github/workflows/build-v16.yml` builds Android and Windows on their respective hosted runners and uploads artifacts. GitHub Actions must complete successfully before claiming an APK or EXE is built. The Windows runner must have the Visual Studio C++ workload and Inno Setup installed.
