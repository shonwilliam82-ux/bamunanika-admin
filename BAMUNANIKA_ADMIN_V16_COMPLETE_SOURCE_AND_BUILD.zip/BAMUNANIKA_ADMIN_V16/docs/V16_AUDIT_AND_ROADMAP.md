# V16 source audit and implementation roadmap

## Archive inspection
The supplied combined package is a ZIP containing an older 162,093,132-byte APK, a 1,455,125-byte Android build-package ZIP and a 637-byte README. The README explicitly states the APK is from an older source revision and does not include the newer dashboard source. The nested corrected source archive contains 27 entries: Flutter app source, tests, Firebase scaffolding, an Inno Setup script, branding asset and CI workflow.

## Findings
### High priority
- The large APK is an old debug/recovered build, not the current source's verified release.
- Firebase is optional and disabled by default; no real project credentials are present.
- Dashboard guest/case forms use local SharedPreferences JSON, not Firestore.
- Current location sharing control is only a local UI preview; it does not publish coordinates to the backend.
- No guest companion app or trusted device registration/consent workflow is included.
- Existing local passcode is prototype-grade and is not a substitute for Firebase Authentication, role-based authorization or secure device storage.

### Platform and release checks
- Android release must be built from this V16 source and signed with a protected release key.
- Windows release must be built on a Windows runner and tested on Windows 11; packaging an EXE folder is not the same as a verified installer.
- Camera, microphone, GPS and map tile access need physical-device testing.
- Firestore/Storage rules and Cloud Functions need emulator tests and a security review.
- Current tests are only model smoke tests plus a placeholder widget test; coverage must be expanded.

## Staged implementation
1. V16 source/version consolidation and reproducible CI.
2. Configure Firebase project and Authentication; provision admin claims only from a trusted server.
3. Wire admin login and guest/case CRUD to Firestore with role checks.
4. Build a separate guest/device companion app with registration codes and explicit owner consent.
5. Implement live-location publishing only while the owner has sharing enabled; stop must revoke and delete the live document.
6. Add audit logs, account recovery, retention/deletion and backups.
7. Run Android and Windows 11 hardware tests, security review, signing and release acceptance.

## Acceptance criteria before public release
- No debug APK distributed as a production app.
- No placeholder credentials or secrets committed.
- A non-admin cannot access admin screens or other users' data.
- A device cannot publish location without authenticated, explicit owner consent.
- Stop Sharing removes access and the live record promptly.
- Tests pass, Windows installer launches on a clean Windows 11 machine, and Android APK installs/updates on target devices.
