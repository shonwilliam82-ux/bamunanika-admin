# Security and privacy status

## Implemented in this development build
- Terms and consent screen appears before first use.
- Location is requested only after the user presses LOCATE NOW and grants OS permission.
- Camera and microphone are invoked only by visible user actions and OS permission prompts.
- The local administrator passcode is salted and SHA-256 hashed in SharedPreferences; legacy plain local passcodes migrate after successful sign-in.
- Location sharing is not remotely transmitted in this build. The visible switch is a local preview only.

## Not production security
SharedPreferences is not a secure credential vault. A salted single SHA-256 hash is not a substitute for a hardened password KDF or platform keystore. This local passcode is a convenience lock, not server authentication. Do not reuse an important password here.

## Before deployment
1. Configure Firebase Authentication and create administrator custom claims using a trusted Admin SDK environment only.
2. Wire screens to authenticated Firestore operations; do not trust client-supplied role fields.
3. Add App Check, rate limits, audit trails, backup/restore, data retention and deletion procedures.
4. Test Firestore and Storage rules with the Firebase Emulator Suite and an independent security review.
5. Keep location sharing off by default. If implemented, require per-device opt-in, a persistent visible indicator, authorized viewers, a Stop Sharing action, and immediate revocation.
6. Never implement covert tracking, hidden recording, or remote camera/microphone activation.
