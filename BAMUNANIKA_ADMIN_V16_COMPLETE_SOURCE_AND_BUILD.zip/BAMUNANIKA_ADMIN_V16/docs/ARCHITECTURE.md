# BAMUNANIKA ADMIN V16 architecture

## Shared client
Flutter provides one codebase for Android and Windows. The UI is responsive and targets mobile, tablet and 1920×1080 desktop layouts.

## Modules
- `lib/models/`: guest, case and location data models.
- `lib/services/firebase_service.dart`: Firebase initialization boundary, email/password auth, Firestore repositories and callable Functions.
- `lib/main.dart`: development dashboard and local-first user experience.
- `firebase/`: Firestore/Storage rules, indexes and Cloud Functions.
- `.github/workflows/`: CI builds for Android and Windows.

## Data collections
- `users/{uid}`: profile and role metadata (admin claim must be assigned server-side).
- `guests/{guestId}`: guest profile, contact, registration code and creator UID.
- `cases/{caseId}`: case details, linked guest ID, status and creator UID.
- `liveLocations/{uid}`: latest location only while the owner has enabled sharing.
- `registrationCodes/{code}`: server-created one-time code records.

## Important limits
This is an integration-ready development baseline, not a production-certified tracking or case-management system. The existing forms are still local-first; Firebase calls need to be connected to the UI, role provisioning and guest-facing registration flow. Background location, push notifications, remote media workflows and Windows installer packaging are not implemented.
