# V16 release checklist

## Backend and security
- [ ] Configure Firebase project for Android and Windows; never commit service-account keys.
- [ ] Enable Email/Password Authentication and provision admin custom claims from a trusted environment.
- [ ] Wire login and guest/case UI to Firebase; remove prototype-only admin gate for production.
- [ ] Test Firestore and Storage rules in Firebase Emulator Suite.
- [ ] Add device registration, consent records, audit logs, recovery, retention, deletion and backups.
- [ ] Build a separate guest/device companion app.
- [ ] Test opt-in location sharing, persistent visible indicator and immediate stop/delete behavior on real devices.

## Android
- [ ] Configure application ID and signing key using protected GitHub Actions secrets.
- [ ] Build optimized release APK from V16 source.
- [ ] Install, upgrade and test on target Android versions and hardware.
- [ ] Verify GPS, camera, microphone, network and permission-denial flows.

## Windows 11
- [ ] Build x64 release on Windows runner.
- [ ] Test dashboard at 1920x1080 and smaller window sizes.
- [ ] Test map/network behavior and available camera/microphone hardware.
- [ ] Install on a clean Windows 11 machine and verify uninstall/upgrade.
- [ ] Sign installer and executable before public distribution.

## Release gate
- [ ] `flutter analyze` passes.
- [ ] `flutter test` passes with meaningful feature tests.
- [ ] Privacy/security review completed.
- [ ] No debug builds or placeholder Firebase configuration distributed.
