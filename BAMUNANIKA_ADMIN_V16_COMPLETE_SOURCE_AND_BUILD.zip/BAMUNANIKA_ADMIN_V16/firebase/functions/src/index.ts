import {onCall, HttpsError} from "firebase-functions/v2/https";
import {initializeApp} from "firebase-admin/app";
import {getFirestore, FieldValue} from "firebase-admin/firestore";
import {randomBytes} from "node:crypto";
initializeApp();
const db = getFirestore();

// Server-generated registration codes; clients cannot write this collection.
export const createGuestRegistrationCode = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const isAdmin = request.auth.token.admin === true;
  if (!isAdmin) throw new HttpsError("permission-denied", "Administrator access required.");
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = `BAM-${randomBytes(4).toString("hex").toUpperCase()}`;
    const ref = db.collection("registrationCodes").doc(code);
    const exists = await ref.get();
    if (!exists.exists) {
      await ref.create({createdAt: FieldValue.serverTimestamp(), createdBy: request.auth.uid, used: false});
      return {code};
    }
  }
  throw new HttpsError("resource-exhausted", "Could not generate a unique code. Try again.");
});
