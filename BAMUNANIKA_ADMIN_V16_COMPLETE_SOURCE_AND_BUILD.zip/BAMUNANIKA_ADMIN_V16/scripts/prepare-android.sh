#!/usr/bin/env bash
set -euo pipefail
flutter create --platforms=android .
cp platform-templates/android/app/src/main/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release
