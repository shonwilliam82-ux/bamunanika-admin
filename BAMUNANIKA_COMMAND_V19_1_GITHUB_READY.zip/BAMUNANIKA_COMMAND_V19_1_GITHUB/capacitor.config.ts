import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.bamunanika.command',
  appName: 'BAMUNANIKA COMMAND',
  webDir: 'www',
  bundledWebRuntime: false
};
export default config;
