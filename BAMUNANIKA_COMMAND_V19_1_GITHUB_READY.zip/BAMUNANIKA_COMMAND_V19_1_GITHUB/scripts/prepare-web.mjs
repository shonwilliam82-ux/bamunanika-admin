import { cp, mkdir, rm } from 'node:fs/promises';
const root = new URL('../', import.meta.url);
const out = new URL('../www/', import.meta.url);
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const name of ['index.html', 'manifest.webmanifest', 'sw.js', 'assets']) {
  await cp(new URL(`../${name}`, import.meta.url), new URL(`../www/${name}`, import.meta.url), { recursive: true });
}
console.log('Prepared Capacitor web assets in www/');
