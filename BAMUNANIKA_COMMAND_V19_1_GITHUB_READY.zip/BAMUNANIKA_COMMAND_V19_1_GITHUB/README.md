# BAMUNANIKA COMMAND V19.1

A local-first operations workspace packaged for GitHub, browser/PWA hosting, Android APK builds, and a Windows installer.

## Included
- Operations register
- Personnel roster and manual attendance
- Device GPS and geofence distance check
- Device camera capture
- SHA-256 hashing of selected evidence files
- Vehicle and fuel log
- Local activity log
- JSON backup and restore
- PWA offline shell
- Capacitor Android build workflow
- Electron Windows installer workflow

## Important limitations
This is a new V19.1 implementation, not an exact modification of the earlier V9/V15 source. Data remains in browser/device local storage. It does not include a hosted backend, cloud synchronization, multi-user access control, immutable audit storage, remote CCTV, dispatch/radio integrations, or server-side evidence custody. The access code is a local convenience lock, not production authentication. Do not use it as the sole system for sensitive or safety-critical operations.

GPS and camera permissions require a secure browser context (HTTPS or localhost) and user approval. Android and Windows builds wrap the same web application; they do not turn the local data store into a cloud service.

## Run as a website
Serve this folder over HTTPS or localhost. GitHub Pages can host it: push the project to the `main` branch and enable GitHub Actions as the Pages source in repository Settings → Pages.

## Android APK
The `Build BAMUNANIKA COMMAND Android APK` workflow creates a debug APK. In GitHub, open **Actions**, select that workflow, choose **Run workflow**, then download the artifact from the completed run. A release APK signed for distribution requires a private signing key and repository secrets; none are included here.

## Windows installer
The `Build BAMUNANIKA COMMAND Windows Installer` workflow creates a Windows NSIS installer. Open **Actions**, select the workflow, run it, then download the installer artifact from the completed run.

## Local development
```bash
npm install
npx cap add android
npx cap sync android
```
For the Windows package, run `npm run desktop:dist` on Windows (or use the GitHub Actions workflow).
